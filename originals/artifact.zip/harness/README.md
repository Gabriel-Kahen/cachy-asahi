# Apps16 native build pair and finite installed lifecycle candidate

Exact recipe a32501a76b79b65d175c8eefc2b4f741ec0388e5 (0.1.0-16). Ordered54 Apps (45 original+9 planner) +32 inventory +8 stage =94 source tests; exactly three OK blocks, no skips/failures. Runtime1/clientv2, installed15/2/4 controls, two homes, signed574/575/577 lifecycle, full metadata/security/crypto and all original clocks/retirement remain mandatory. Source-only; no new native or performance acceptance.

## Historical Apps15 parent README (not current selected identity)

# Apps15 native build pair and finite installed lifecycle candidate

Exact recipe 308c63abacc2435aeebb74f988f7a1f362b5b942 (0.1.0-15). Ordered45 Apps +32 inventory +8 stage =85 source tests; exactly three OK blocks, no skips/failures. Runtime1/clientv2, installed15/2/4 controls, two homes, signed574/575/577 lifecycle, full metadata/security/crypto and all original clocks/retirement remain mandatory. Source-only; no new native or performance acceptance.

## Historical Apps14 parent README (not current selected identity)

# Apps14 native build pair and finite installed lifecycle candidate

Exact recipe 2e58341f6fa25de5167fd8a59566b3dd7f066fe3 (0.1.0-14). Ordered45 Apps +24 inventory +8 stage =77 source tests; exactly three OK blocks, no skips/failures. Runtime1/clientv2, installed15/2/4 controls, two homes, signed574/575/577 lifecycle, full metadata/security/crypto and all original clocks/retirement remain mandatory. Source-only; no new native or performance acceptance.

## Historical Apps13 parent README (not current selected identity)

# Apps13 native build pair and finite installed lifecycle candidate

Current recipefa27f3294385884e8cb0d33720dc5e1e074178d4 (0.1.0-13); distinct source suites45+18+8=71, exactly three OK blocks in that order and no skips/failures. All installed15 Apps/2 client/4 stage controls and signed574/575/577 lifecycle, clocks/security and retirement remain held. Host measurements are not native fit.

## Historical Apps12 parent README (not the current selected identity)

# Apps12 and opt-in client v2 native software trial

Finite derivative of the complete pinned Apps/Runtime/Cache owner, keeping its native builder, archive/pkginfo/BUILDINFO/content pair gate, exact574 producer, signed Runtime575 image, ordinary-user preservation, capped leases, dependency-image/producer/key retirement, and all2350/240/600-second plus192MiB bounds. Cache's slot is explicitly replaced by client-v2; Apps maps to its separate apps12 recipe. No Cache apply,604,16K,full574 repair,M2 or release acceptance follows. Runtime1 is rebuilt twice; it is a new pair, not assumed equal to historical archives.

The source-only default policy keeps candidate source and all product source identities NULL and refuses production calls before actors. prepare.py emits a fresh closed source. An explicit Root --candidate-source must be a real40-character Git commit whose three recipe sets independently match, and produces only a bound private source clone. It cannot invent an actual run. Root then freezes/publishes source and dispatches one genuine native trial. The source/workflow proof must pass before secrets or actors.

Both new pairs use the same signed Runtime575 dependency image and exact dependency checks. Base consumers total6 and Runtime-image builders total4; each original lease cap remains8. The installed signed ALPM path has the original five install/reinstall/remove/reinstall/remove transitions, exact577 then574 inventory, exact payload ownership, original574 payload/rawDB preservation and fresh/existing ordinary-user configuration/output preservation. Removal argv explicitly orders client-v2,Apps,Runtime. Installed Apps catalog/plans and actual577 metadata checks remain mandatory. All15 new inventory controls execute against installed Apps modules/CLI, and two genuine signed tilde source lookup/export/tamper/populated-checkpoint controls execute through installed client_v2.py and Runtime siblings, in each installed phase and both homes. TEST fixture source is read-only code from the exact source closure; no collected code is imported. Native host page size is required/reported4096 and grants no16K/hardware credit.

Root owns publication, actual run binding, once-original retention and acceptance. Local controls are source/data/staged checks only.

This Apps12 successor uses genuine recipe31bc46cdd58840e5c4337d2270a307d23a171373 (0.1.0-12). Root's published profile binds that recipe; the constructor's default remains NULL. The complete native package check gate requires exactly45 Apps,15 inventory and8 stage checks (68 total), three OK blocks, no errors/failures/skips; old8-inventory or swapped/partial groups refuse. The installed15 Apps/2 client/4 stage fixtures, all574/575/577 lifecycle/preservation checks, original clocks/security/transport and ordered retirement remain held. Host fixture timing motivates this trial; native fit and performance remain unmeasured.

Apps12 corrects the packaged runtime provenance while holding every Apps11 runtime byte. Native checks require45+15+8=68 tests, three OK blocks, and no skips/failures. The signed installed lifecycle, source clocks and security controls remain unchanged. Historical Apps11 native results do not establish corrected provenance.
