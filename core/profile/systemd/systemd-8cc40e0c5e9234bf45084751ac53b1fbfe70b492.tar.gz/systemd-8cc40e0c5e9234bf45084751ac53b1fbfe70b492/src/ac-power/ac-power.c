/* SPDX-License-Identifier: LGPL-2.1-or-later */

#include "sd-json.h"

#include "battery-util.h"
#include "build.h"
#include "log.h"
#include "main-func.h"
#include "string-util.h"
#include "verbs.h"

static bool arg_verbose = false;

static enum {
        ACTION_AC_POWER,
        ACTION_LOW,
} arg_action = ACTION_AC_POWER;

COMMAND(
        "systemd-ac-power\0",
        "Report whether we are connected to an external power source.",
        .man_pages = "systemd-ac-power(1)\0",
);

static int parse_argv(int argc, char *argv[]) {

        assert(argc >= 0);
        assert(argv);

        OptionParser opts = { argc, argv };

        FOREACH_OPTION_OR_RETURN(c, &opts)
                switch (c) {
                OPTION_COMMON_HELP:
                        return command_print_help();

                OPTION_COMMON_VERSION:
                        return version();

                OPTION('v', "verbose", NULL, "Show state as text"):
                        arg_verbose = true;
                        break;

                OPTION_LONG("low", NULL, "Check if battery is discharging and low"):
                        arg_action = ACTION_LOW;
                        break;

                OPTION_COMMON_INTROSPECT_CLI:
                        return introspect_cli(SD_JSON_FORMAT_OFF);
                }

        if (option_parser_get_n_args(&opts) > 0)
                return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "This program takes no arguments.");

        return 1;
}

static int run(int argc, char *argv[]) {
        int r;

        /* This is mostly intended to be used for scripts which want
         * to detect whether AC power is plugged in or not. */

        log_setup();

        r = parse_argv(argc, argv);
        if (r <= 0)
                return r;

        if (arg_action == ACTION_AC_POWER) {
                r = on_ac_power();
                if (r < 0)
                        return log_error_errno(r, "Failed to read AC status: %m");
        } else {
                r = battery_is_discharging_and_low();
                if (r < 0)
                        return log_error_errno(r, "Failed to read battery discharging + low status: %m");
        }

        if (arg_verbose)
                puts(yes_no(r));

        return r == 0;
}

DEFINE_MAIN_FUNCTION_WITH_POSITIVE_FAILURE(run);
