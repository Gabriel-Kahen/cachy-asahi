"""Inert management/profile adapter controls; no GUI, package, service, VM or network actor."""
import base64
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import native_contract as N
import candidates as A
import prepare as P
import management_contract as C
import management_root as R

ROOT=Path(os.environ.get('WELCOME_MANAGEMENT_SOURCE',Path(__file__).resolve().parents[3]))
HERE=Path(__file__).resolve().parent
UI=dict(labels=dict(management='Management',doctor='Run Doctor',orphans='Assess orphan packages'),
    strings=dict(running='Running check…',complete='Elapsed:',failure='Check failed.',unavailable='The optional tool is not installed or executable. This check is unavailable.'),
    raw_preview_suffix='\n[Raw preview truncated at 64 KiB.]',max_output_bytes=1024**2)


def node(text,*,name='',enabled=True,showing=True):
    raw=text.encode();return dict(name_base64=base64.b64encode(name.encode()).decode(),role=43,showing=showing,selected=False,checked=False,enabled=enabled,sensitive=enabled,
        body_base64=base64.b64encode(raw).decode(),text_sha256=C.sha(raw),text_bytes=len(raw))


def child(tool='orphans',pid=100,parent=90,welcome=80,stopped=False):
    argv=['/usr/bin/cachy-asahi-'+tool,'--json' if tool=='doctor' else 'assess']
    return dict(pid=pid,starttime=1000+pid,supervisor_pid=parent,welcome_pid=welcome,uid=[23001]*4,pgid=pid,stopped=stopped,
        argv=argv,raw_argv=['/usr/bin/python3',*argv],exe='/usr/bin/python3.14',original_executable=argv[0])


def events():
    inventory={'fixture-'+str(i):'1' for i in range(594)}
    doctor=dict(tool='cachy-asahi-doctor',scope='local observations only',checks=[dict(state='checked')],coverage=dict(checked=1,unknown=0,unavailable=0))
    orphan=dict(scope=C.SCOPE,apply_supported=False,root='/',dbpath='/var/lib/pacman',candidates=[],broken_dependencies=[],packages={n:dict(version=v,candidate=False) for n,v in inventory.items()})
    refusal=dict(verification='REFUSED',apply_supported=False,reason='existing ALPM lock: active or uncertain; readonly assessment refused')
    rows=[]
    for stage in ('minimal','overlay'):
        reports={};actions=[]
        for label,scope,scroll in C.action_plan(UI):
            proof=dict(status='PASS',pid=80,actions=0 if scroll else 1,action_name='scroll-anywhere' if scroll else 'click')
            if scroll:proof['interface']='Component'
            actions.append(dict(event='management_action',stage=stage,sequence=len(actions)+1,pid=80,label=label,scope=scope,scroll=scroll,proof=proof,physical_input='NOT_RUN'))
        rows.extend(actions[:2])
        for view in C.MANAGEMENT_VIEWS:
            kind=view.removeprefix('management-')
            if kind=='absent':expected=dict(text=[UI['strings']['unavailable']],buttons={UI['labels']['doctor']:False,UI['labels']['orphans']:False})
            elif kind=='closing':
                rows.extend(actions[-2:]);expected=dict(text=[UI['strings']['running']],buttons={UI['labels']['orphans']:False})
            else:
                start=3+4*('doctor','orphans','failure').index(kind)
                if kind=='doctor':rows.append(actions[2])
                rows.extend(actions[start:start+3]);tool='doctor' if kind=='doctor' else 'orphans'
                raw=C.encoded(dict(doctor=doctor,orphans=orphan,failure=refusal)[kind]);_,summary=C.report(raw,kind,inventory)
                expected=dict(text=[UI['strings']['failure' if kind=='failure' else 'complete'],summary,C.preview(raw,UI)],buttons={UI['labels'][tool]:True})
                reports[kind]=dict(base64=base64.b64encode(raw).decode(),sha256=C.sha(raw),bytes=len(raw),gui_process=child(tool))
                if kind=='doctor':reports[kind]['gui_report']=dict(base64=base64.b64encode(raw).decode(),sha256=C.sha(raw),bytes=len(raw))
            nodes=[node(text) for text in expected['text']]+[node('',name=label,enabled=enabled) for label,enabled in expected['buttons'].items()]
            snap=dict(status='PASS',pid=80,nodes=nodes)
            semantic=dict(snapshot=snap,snapshot_sha256=C.sha(C.encoded(snap)),expected=expected,summary=C.snapshot(snap,80,view,expected))
            rows.append(dict(event='frame_ready',stage=stage,view=view,welcome_pid=80,semantic=semantic,capture_after_ms=5000,hardware='NOT_RUN',physical_input='NOT_RUN'))
            if kind in ('doctor','orphans','failure'):rows.append(actions[start+3])
        rows.append(dict(event='management_result',stage=stage,reports=reports,closing_process=child(stopped=True),welcome_exit=0,
            owned_group_absent=True,owned_helper_absent=True,owned_supervisor_absent=True,metadata_readonly=True,nonselected_database='PRESERVED',inventory=inventory,
            present_count=594,absent_count=592,scope='GENERIC4K_UNPRIVILEGED_ACTUAL_DEFAULT_TOOLS',hardware='NOT_RUN'))
    return rows,dict(status='VERIFIED_NATIVE_CANDIDATES',products={n:{} for n in N.NAMES},policy=dict(ui=UI))


def result(rows):return next(e for e in rows if e['event']=='management_result')


class Semantics(unittest.TestCase):
    def test_final_ui_binding_required(self):
        C.interface(dict(ui=UI))
        for key in UI:
            bad=copy.deepcopy(UI);bad.pop(key)
            with self.subTest(key=key),self.assertRaises(ValueError):C.interface(dict(ui=bad))
    def test_actual_text_hash_and_optional_disabled_state(self):
        value=dict(status='PASS',pid=80,nodes=[node('unavailable',name=UI['labels']['orphans'],enabled=False)])
        C.snapshot(value,80,'management-absent',dict(text=['unavailable'],buttons={UI['labels']['orphans']:False}))
        for field in ('enabled','sensitive','body_base64','text_sha256'):
            bad=copy.deepcopy(value);bad['nodes'][0][field]=True if field in ('enabled','sensitive') else '0'*64
            with self.subTest(field=field),self.assertRaises(Exception):C.snapshot(bad,80,'management-absent',dict(text=['unavailable'],buttons={UI['labels']['orphans']:False}))
    def test_full_finite_management_receipt_replays(self):
        rows,lock=events();self.assertEqual(C.verify_result(rows,lock)['status'],'PASS_MANAGEMENT_NATIVE_METADATA_PIXELS_PENDING_REVIEW')
    def test_missing_firstframe_or_duplicate_view_refuses(self):
        rows,lock=events()
        for i in [j for j,e in enumerate(rows) if e['event']=='frame_ready']:
            bad=copy.deepcopy(rows);bad.pop(i)
            with self.subTest(i=i),self.assertRaises(ValueError):C.verify_result(bad,lock)
        bad=copy.deepcopy(rows);bad.insert(0,copy.deepcopy(next(e for e in bad if e['event']=='frame_ready')))
        with self.assertRaises(ValueError):C.verify_result(bad,lock)
    def test_wrong_fixed_helper_wrong_user_or_nonretirement_refuses(self):
        rows,lock=events()
        for field,value in (('uid',[0]*4),('argv',['/tmp/fake','assess']),('stopped',False),('pgid',80)):
            bad=copy.deepcopy(rows);result(bad)['closing_process'][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):C.verify_result(bad,lock)
        for field in ('owned_group_absent','owned_helper_absent','owned_supervisor_absent','metadata_readonly'):
            bad=copy.deepcopy(rows);result(bad)[field]=False
            with self.subTest(field=field),self.assertRaises(ValueError):C.verify_result(bad,lock)
    def test_raw_report_drift_scope_or_count_drift_refuses(self):
        rows,lock=events()
        bad=copy.deepcopy(rows);result(bad)['reports']['orphans']['sha256']='0'*64
        with self.assertRaises(ValueError):C.verify_result(bad,lock)
        for field,value in (('present_count',593),('absent_count',591),('scope','M2_PASS'),('hardware','PASS')):
            bad=copy.deepcopy(rows);result(bad)[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):C.verify_result(bad,lock)
    def test_action_and_exact_gui_state_replay_rejects_missing_or_forged_operations(self):
        rows,lock=events()
        for edit in ('missing','pid','scope','proof','state'):
            bad=copy.deepcopy(rows)
            if edit=='missing':bad.pop(0)
            elif edit=='state':
                frame=next(e for e in bad if e['event']=='frame_ready');frame['semantic']['expected']['buttons']={}
                frame['semantic']['summary']=C.snapshot(frame['semantic']['snapshot'],80,frame['view'],frame['semantic']['expected'])
            else:
                row=next(e for e in bad if e['event']=='management_action')
                if edit=='proof':row['proof']['actions']=0
                else:row[edit]=81 if edit=='pid' else 'arbitrary'
            with self.subTest(edit=edit),self.assertRaises(ValueError):C.verify_result(bad,lock)
    def test_doctor_uses_its_actual_gui_timestamp_and_report(self):
        rows,lock=events();row=result(rows)['reports']['doctor'];value=json.loads(base64.b64decode(row['base64']));value['collected_utc']='independent timestamp'
        raw=C.encoded(value);row.update(base64=base64.b64encode(raw).decode(),sha256=C.sha(raw),bytes=len(raw))
        C.verify_result(rows,lock)
        row['gui_report']['sha256']='0'*64
        with self.assertRaises(ValueError):C.verify_result(rows,lock)
    def test_root_counterpart_is_fixed_package_only_and_guarded(self):
        self.assertEqual(R.TOOLS,('cachy-asahi-doctor','cachy-asahi-orphans'))
        text=(HERE/'management_root.py').read_text();self.assertIn('base.guard(True)',text);self.assertNotIn('os.unlink',text)
        self.assertIn('alpm_trans_release',text);self.assertIn('signal.pidfd_send_signal',text)
        self.assertNotIn('shell=True',text);self.assertNotIn('nodeps',text)


class Adapter(unittest.TestCase):
    def test_policy_is_unbound_before_staging(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'runner'
            unbound=N.policy(False);unbound.update(status='UNBOUND_FIXTURE',candidate_source=None)
            with patch.object(N,'read',return_value=unbound),self.assertRaisesRegex(ValueError,'UNBOUND'):P.prepare(ROOT,out,Path('/unused'))
            self.assertFalse(out.exists())
    def test_accepted_adapter_derives24_exact_frames_and_preserves_gates(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);out=root/'runner'
            def stage(source,assets,output):
                output.mkdir();lock=dict(status='SYNTHETIC_TEMPLATE_CONTROL_ONLY',eligibility='PRIVATE_GUI_TRIAL_ONLY',products={},policy=dict(ui=UI))
                (output/'candidate-lock.json').write_bytes(N.encoded(lock));return lock
            with patch.object(N,'verify_source'),patch.object(A,'verify_source'),patch.object(N,'policy',return_value=dict(ui=UI)),patch.object(A,'stage',side_effect=stage):P.prepare(ROOT,out,root/'assets')
            for path in out.glob('*.py'):compile(path.read_text(),str(path),'exec')
            runtime=(out/'desktop574_runtime.py').read_text();guest=(out/'base_guest.py').read_text();session=(out/'session.py').read_text()
            for stage_name in ('minimal','overlay'):
                for view in C.VIEWS:self.assertIn(stage_name+'-'+view,runtime)
            self.assertIn('management_root.serve',guest);self.assertIn('managed_session.SETPRIV',guest);self.assertNotIn('dbus-run-session',guest)
            self.assertIn('MG.exercise',session);self.assertIn('welcome=actor',session)
            self.assertIn('LocalFileSigLevel = Required',runtime);self.assertIn('/tmp/products/TEST-public.asc',runtime)
            self.assertNotIn('test-signing',runtime);self.assertIn('time.monotonic() + 1300',runtime)
            self.assertIn('TimeoutStartSec=1200',(out/'desktop574_fixture.sh').read_text())
            subprocess.run(['/usr/bin/bash','-n',str(out/'desktop574_fixture.sh')],check=True,capture_output=True)
            import ast
            tree=ast.parse(runtime);writes=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='write_text' and n.args and isinstance(n.args[0],ast.JoinedStr)]
            docker=next(n.args[0] for n in writes if any(isinstance(v,ast.Constant) and isinstance(v.value,str) and v.value.startswith('FROM ') for v in n.args[0].values))
            rendered=''.join(v.value if isinstance(v,ast.Constant) else 'owned-base' for v in docker.values)
            run=next(line[4:] for line in rendered.splitlines() if line.startswith('RUN '))
            subprocess.run(['/usr/bin/bash','-n'],input=run,text=True,check=True,capture_output=True)
            self.assertIn("python3 -c 'import json;",run)
            proof=json.loads((out/'runner-proof.json').read_bytes());self.assertGreater(len(proof['files']),20)
    def test_outer_deadlines_allow_the_original_gui_cleanup_budget(self):
        run=(HERE/'run.py').read_text();workflow=(HERE.parents[2]/'.github/workflows/native-arm-welcome-management.yml').read_text()
        self.assertIn("timeout=450 if log.name=='gui-runtime.log'",run)
        self.assertIn('setitimer(signal.ITIMER_REAL,3900)',run)
        self.assertIn('--kill-after=480s 4500s',workflow);self.assertIn('timeout-minutes: 85',workflow)
        self.assertGreater(4500,3900+450);self.assertGreater(85*60,4500+480)
    def test_source_observation_never_substitutes_helpers_or_gui_text(self):
        text=(HERE/'management_phase.py').read_text();self.assertIn("['/usr/bin/cachy-asahi-welcome']",text)
        self.assertIn('report_command(base,kind',text);self.assertNotIn('management_test_configure',text)
        self.assertNotIn('gtk_label_set_text',text);self.assertIn("request('lock')",text)
        self.assertIn("observed('orphans',True)",text);self.assertIn("close(current,False)",text)


if __name__=='__main__':unittest.main()
