# SPDX-License-Identifier: MIT
"""Actual optional-tool absence, reports, refusal and close during an owned real check."""
import base64
import json
import os
from pathlib import Path
import runpy
import stat
import subprocess
import time
from types import SimpleNamespace
import management_contract as C

SEQUENCE=0
CHANNEL=Path('/home/desktop574/management-channel')


def request(operation,**fields):
    global SEQUENCE
    nonce=C.read(CHANNEL/'nonce',64,0).decode();number=SEQUENCE;SEQUENCE+=1
    payload=dict(nonce=nonce,sequence=number,operation=operation,**fields);path=CHANNEL/('request-'+str(number)+'.json');pending=path.with_suffix('.pending')
    with pending.open('xb') as stream:stream.write(C.encoded(payload));stream.flush();os.fsync(stream.fileno())
    pending.chmod(0o600);C.need(not path.exists(),'fresh fixture request required');pending.rename(path);reply=CHANNEL/('reply-'+str(number)+'.json');until=time.monotonic()+90
    while not reply.exists():C.need(time.monotonic()<until,'owned fixture reply deadline');time.sleep(.01)
    value=json.loads(C.read(reply,65536,0));C.need(value.get('nonce')==nonce and value.get('sequence')==number and value.get('status')=='PASS','owned root fixture result differs');return value


def report_command(base,tool,path,env,expected=0):
    argv=['/usr/bin/cachy-asahi-'+('orphans' if tool=='failure' else tool),'--json' if tool=='doctor' else 'assess']
    error_path=path.with_suffix('.stderr');process=None
    with path.open('xb') as out,error_path.open('xb') as err:
        path.chmod(0o600);error_path.chmod(0o600)
        process=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,close_fds=True)
        until=time.monotonic()+40
        try:
            while process.poll() is None:
                C.need(time.monotonic()<until and path.stat().st_size<=C.REPORT_CAP and error_path.stat().st_size<=65536,'actual independent helper report bound/deadline');time.sleep(.02)
            C.need(process.returncode==expected,'actual independent helper return code differs')
        finally:base.terminate(process)
    raw=C.read(path);C.need(not C.read(error_path,65536),'unexpected helper stderr');return raw


def exercise(base,stage,env,logs,workspace,old_welcome,doctor,policy,lock,hooks):
    base.guard(False);C.need(os.getuid()==os.geteuid()==23001 and not os.access('/var/lib/pacman',os.W_OK),'ordinary caller must lack database write/lock access')
    ui=C.interface(policy);reports={};current=old_welcome;closed=None;action_sequence=0
    M=SimpleNamespace(**runpy.run_path('/usr/bin/cachy-asahi-orphans',run_name='independent_snapshot'))
    def stable():
        value=M.database_snapshot(Path('/var/lib/pacman'))[0]
        C.need(all(row['uid']==0 and not row['mode']&0o022 for row in value['nodes'].values()),'actual root-owned nonwritable metadata required')
        return value
    def healthy():hooks['healthy']()
    def a11y(operation,label=None,scope=None):return hooks['a11y'](operation,label,scope=scope)
    def action(label,scope=None,scroll=False):
        nonlocal action_sequence
        value=a11y('scroll' if scroll else 'activate',label,scope)
        if scroll:C.need(value.get('interface')=='Component' and value.get('action_name')=='scroll-anywhere' and value.get('pid')==current.process.pid,'actual scroll interface failed')
        else:C.need(value.get('actions')==1 and value.get('action_name') in ('click','activate','press','switch'),'actual management action failed')
        action_sequence+=1
        base.emit('management_action',stage=stage,sequence=action_sequence,pid=current.process.pid,label=label,scope=scope,scroll=scroll,proof=value,physical_input='NOT_RUN')
    def page(view,expected):
        def probe():
            value=a11y('snapshot')
            try:summary=C.snapshot(value,current.process.pid,view,expected)
            except ValueError:return None
            return dict(snapshot=value,snapshot_sha256=C.sha(C.encoded(value)),summary=summary,expected=expected)
        return hooks['wait'](probe,healthy,45,'actual '+view)
    def capture(view,expected):hooks['capture'](view,page(view,expected))
    def close(actor,finish=True):
        target='address:'+hooks['window'](actor.process.pid)['address']
        C.need(hooks['command'](['/usr/bin/hyprctl','dispatch',f'hl.dsp.window.close({{window="{target}"}})'],'management-close').strip()=='ok','actual Welcome close failed')
        actor.process.wait(timeout=15);C.need(actor.process.returncode==0,'Welcome management close exit differs');hooks['adopt'](None)
        if finish:actor.finish()
    def start():
        actor=base.Logged(['/usr/bin/cachy-asahi-welcome'],stage+'-management-welcome-'+str(SEQUENCE),logs,env)
        hooks['adopt'](actor);hooks['place'](actor.process.pid,'welcome',initial=True)
        hooks['wait'](lambda:hooks['a11y']('snapshot',pending=True),hooks['healthy'],45,'actual owned Welcome accessibility')
        return actor
    def observed(tool,stop=False):
        request('arm',tool=tool,welcome_pid=current.process.pid,stop=stop);action(ui['labels'][tool])
        def probe():
            row=request('observed')['process']
            return row if row is not None else None
        result=hooks['wait'](probe,healthy,20,'original default '+tool+' process')
        C.process(result,tool,current.process.pid,stop);return result
    try:
        close(old_welcome);missing=request('remove');C.need(len(missing['inventory'])==592,'optional tools not actually removed')
        current=start();action(ui['labels']['management']);action(ui['labels']['orphans'],scroll=True)
        capture('management-absent',dict(text=[ui['strings']['unavailable']],buttons={ui['labels']['doctor']:False,ui['labels']['orphans']:False}))
        close(current);restored=request('restore');inventory=restored['inventory'];C.need(len(inventory)==594,'exact optional helper profile not restored')
        current=start();action(ui['labels']['management'])
        for kind in ('doctor','orphans','failure'):
            before=stable()
            if kind=='failure':request('lock')
            raw=report_command(base,kind,workspace/(kind+'-actual.json'),env,1 if kind=='failure' else 0)
            data,summary=C.report(raw,kind,inventory);C.need(len(raw)<=ui['max_output_bytes'],'actual report exceeds product bound; no limit waiver')
            tool='doctor' if kind=='doctor' else 'orphans';action(ui['labels'][tool],scroll=True)
            child=observed(tool)
            # Open only the known tool frame's raw expander; duplicate labels stay scoped.
            action('View report',scope='Doctor' if tool=='doctor' else 'Orphan assessment')
            gui_report=None
            if kind=='doctor':
                # Doctor includes collected_utc and live service observations. Retain its actual GTK report,
                # then derive its own conclusion; the independent actual run remains separate evidence.
                def actual_doctor():
                    snap=a11y('snapshot');matches=[]
                    for _,row,text in C.names(snap):
                        if row['showing'] and text and text.startswith('{'):
                            try:value,conclusion=C.report(text.encode(),'doctor',inventory)
                            except (ValueError,KeyError,TypeError):continue
                            matches.append((text,conclusion))
                    return matches[0] if len(matches)==1 else None
                preview,summary=hooks['wait'](actual_doctor,healthy,45,'actual GTK Doctor report')
                gui_raw=preview.encode();gui_report=dict(base64=base64.b64encode(gui_raw).decode(),sha256=C.sha(gui_raw),bytes=len(gui_raw))
            else:preview=raw[:65536].decode(errors='replace')+(ui['raw_preview_suffix'] if len(raw)>65536 else '')
            expected=dict(text=[ui['strings']['failure' if kind=='failure' else 'complete'],summary,preview],buttons={ui['labels'][tool]:True})
            capture('management-'+kind,expected)
            reports[kind]=dict(gui_report=gui_report,base64=base64.b64encode(raw).decode(),sha256=C.sha(raw),bytes=len(raw),gui_process=child,metadata_only=True)
            action('View report',scope='Doctor' if tool=='doctor' else 'Orphan assessment')
            if kind=='failure':
                request('unlock');after=stable()
                C.need({n:r for n,r in before['nodes'].items() if n!='.'}=={n:r for n,r in after['nodes'].items() if n!='.'},'held-lock case changed nonlock metadata')
            else:C.need(stable()==before and not Path('/var/lib/pacman/db.lck').exists(),'actual management/independent commands changed metadata or created lock')
        closing_before=stable();action(ui['labels']['orphans'],scroll=True);closing=observed('orphans',True)
        capture('management-closing',dict(text=[ui['strings']['running']],buttons={ui['labels']['orphans']:False}))
        close(current,False);closed=current
        def retired():
            value=request('retired')
            return value if all(value[k] for k in ('helper_absent','supervisor_absent','group_absent')) else None
        retirement=hooks['wait'](retired,lambda:None,10,'owned management group retirement')
        C.need(stable()==closing_before and not Path('/var/lib/pacman/db.lck').exists(),'closing check changed metadata or created lock')
        C.need(retirement['inventory']==inventory and retirement['nonselected_database']=='PRESERVED','GUI fixture mutated nonselected metadata')
        base.emit('management_result',stage=stage,reports=reports,closing_process=closing,welcome_exit=closed.process.returncode,
            owned_group_absent=True,owned_helper_absent=True,owned_supervisor_absent=True,metadata_readonly=True,
            nonselected_database='PRESERVED',inventory=inventory,present_count=594,absent_count=592,
            scope='GENERIC4K_UNPRIVILEGED_ACTUAL_DEFAULT_TOOLS',hardware='NOT_RUN')
        return closed
    finally:
        if closed is None and current is not None:
            base.terminate(current.process);current.finish();hooks['adopt'](None)
