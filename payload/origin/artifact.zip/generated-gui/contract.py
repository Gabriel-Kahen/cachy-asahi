# SPDX-License-Identifier: MIT
import json
from pathlib import Path
import candidates
import gui_contract as C
import management_contract as M
legacy=C.load('management_accepted_gui_contract','legacy_contract.py')
verify_source=candidates.verify_source

def verify_result(events,lock):
    baseline=[e for e in events if not(e.get('event')=='frame_ready' and e.get('view') in M.MANAGEMENT_VIEWS)]
    old=dict(lock,products={n:lock['products'][n] for n in ('cachy-asahi-welcome','cachy-asahi-doctor')})
    views=C.VIEWS
    try:
        C.VIEWS=M.BASE_VIEWS
        original=legacy.verify_result(baseline,old)
        C.VIEWS=views
        for stage in ('minimal','overlay'):
            reference=next(e for e in baseline if e.get('event')=='frame_ready' and e.get('stage')==stage)
            for frame in (e for e in events if e.get('event')=='frame_ready' and e.get('stage')==stage and e.get('view') in M.MANAGEMENT_VIEWS):
                C.together(list(frame['windows'].values()),frame['welcome_pid'],reference['doctor_pid'],frame['view'])
                C.need(all(frame[k]==reference[k] for k in ('doctor_pid','compositor_pid','worker','doctor_proof_sha256','managed_identity','producer_lifecycle')),
                       'management capture must retain actual managed bus/compositor/Doctor worker')
    finally:C.VIEWS=views
    return dict(baseline=original,management=M.verify_result(events,lock),visual_review='NOT_RUN',hardware='NOT_RUN')
