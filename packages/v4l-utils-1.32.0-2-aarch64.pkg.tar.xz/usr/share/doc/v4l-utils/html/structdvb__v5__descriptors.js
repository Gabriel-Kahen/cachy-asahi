var structdvb__v5__descriptors =
[
    [ "delivery_system", "structdvb__v5__descriptors.html#afd3cf285c450c701a0d92d2facc45d78", null ],
    [ "entry", "structdvb__v5__descriptors.html#a5be04419162c97e5b08e18b05091f2ac", null ],
    [ "nit", "structdvb__v5__descriptors.html#a52495516e3fa34a370c784682aec63cf", null ],
    [ "num_entry", "structdvb__v5__descriptors.html#a4624a544d8277bef6be6f9c1dbb71385", null ],
    [ "num_other_nits", "structdvb__v5__descriptors.html#ab2ac6078a31e67d4118ea4c0ec67bbbe", null ],
    [ "num_other_sdts", "structdvb__v5__descriptors.html#a35aceacb0e8ae841464e9cfd0dc718bc", null ],
    [ "num_program", "structdvb__v5__descriptors.html#a97a8f175f51f38604648862ad2fbf68a", null ],
    [ "other_nits", "structdvb__v5__descriptors.html#af35421b853cbf7ced510f3ccad18188d", null ],
    [ "other_sdts", "structdvb__v5__descriptors.html#a113f36722287d6ded4df2f6d2d188b78", null ],
    [ "pat", "structdvb__v5__descriptors.html#a23104a22469ef8d3003d340e535665b7", null ],
    [ "program", "structdvb__v5__descriptors.html#a7e1a410b659d3383dc2ebc1478382d99", null ],
    [ "sdt", "structdvb__v5__descriptors.html#a910b25b1686997c535bc7b8d99a8641d", null ],
    [ "vct", "structdvb__v5__descriptors.html#a98f9f93e3608838a5a3a7f2f1e279b00", null ]
];