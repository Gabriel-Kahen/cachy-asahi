var structdvb__table__pat =
[
    [ "header", "structdvb__table__pat.html#a8eabc5d575be9de5627514698464a053", null ],
    [ "program", "structdvb__table__pat.html#a452f9602c4c9e10b2dcbf408a5a66e3e", null ],
    [ "programs", "structdvb__table__pat.html#a6cd61133112801e26a113893fda0f623", null ]
];