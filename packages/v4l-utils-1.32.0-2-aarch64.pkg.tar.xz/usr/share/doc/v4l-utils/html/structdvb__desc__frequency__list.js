var structdvb__desc__frequency__list =
[
    [ "bitfield", "structdvb__desc__frequency__list.html#a7e7e488a673feecb05ae9df2c5e4559c", null ],
    [ "freq_type", "structdvb__desc__frequency__list.html#a6d2bb7786bda53518fe1652ba2aa88e5", null ],
    [ "frequencies", "structdvb__desc__frequency__list.html#aedf5ae16f888681feedd58a57dd7804b", null ],
    [ "frequency", "structdvb__desc__frequency__list.html#a93748158280a2ee99531fae956ce9014", null ],
    [ "length", "structdvb__desc__frequency__list.html#aa31213da6e37afae117a2e91534a719f", null ],
    [ "next", "structdvb__desc__frequency__list.html#a4b5936bae78d9bbb44de7ea82bd4abd0", null ],
    [ "reserved", "structdvb__desc__frequency__list.html#a19d0ea05b03ce41b7b2f72f583246a36", null ],
    [ "type", "structdvb__desc__frequency__list.html#a20f5fe4bceb8a6f5849d11cac5098ec7", null ]
];