var structdvb__desc__service =
[
    [ "length", "structdvb__desc__service.html#a6ba36ce6bbced769990b4a0b60b42501", null ],
    [ "name", "structdvb__desc__service.html#a7353fa626d9f16096f22236dd2306ff4", null ],
    [ "name_emph", "structdvb__desc__service.html#a7e674562d5d2f0d642e74e76422b5a4e", null ],
    [ "next", "structdvb__desc__service.html#ae14c7a8b599897cd18a63e0e5983fc7f", null ],
    [ "provider", "structdvb__desc__service.html#a5ae2a33a2445d19ca8b75d693233f4f3", null ],
    [ "provider_emph", "structdvb__desc__service.html#a73ee58174f6e9db80715a951e13ca795", null ],
    [ "service_type", "structdvb__desc__service.html#a6bb87991c43fb52f9d3b883437513054", null ],
    [ "type", "structdvb__desc__service.html#a6b14632b9bc3b0ea46f1b7ae30949683", null ]
];