var structdvb__parse__struct =
[
    [ "delsys", "structdvb__parse__struct.html#a602118dd77afc244b83145b06e5986dd", null ],
    [ "id", "structdvb__parse__struct.html#a136c366426e79d161318e5fd9fd9d03a", null ],
    [ "size", "structdvb__parse__struct.html#a05c5e02000634b8b5e2d3f2713a85242", null ],
    [ "table", "structdvb__parse__struct.html#a8fcfa39dbab86b36eaba525ada96ef77", null ]
];