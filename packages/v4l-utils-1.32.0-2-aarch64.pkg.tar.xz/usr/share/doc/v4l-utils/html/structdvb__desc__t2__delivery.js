var structdvb__desc__t2__delivery =
[
    [ "bandwidth", "structdvb__desc__t2__delivery.html#aa1de5d8c31aeabc8c7eb65cb96d71eda", null ],
    [ "bitfield", "structdvb__desc__t2__delivery.html#abda2628829a3968952e40e61bfd2e7fa", null ],
    [ "cell", "structdvb__desc__t2__delivery.html#a7f6d3425c77b58c6ee0836ab946a0e73", null ],
    [ "centre_frequency", "structdvb__desc__t2__delivery.html#a8e30237c1a1ef72e22d30c5c7528f06f", null ],
    [ "frequency_loop_length", "structdvb__desc__t2__delivery.html#a56cad8cb972c41c82d623346e57bf7b8", null ],
    [ "guard_interval", "structdvb__desc__t2__delivery.html#a582b9fe778db47e8fb113909aae438f7", null ],
    [ "num_cell", "structdvb__desc__t2__delivery.html#a7a5f020923cb78541b55c6b9e95be33f", null ],
    [ "other_frequency_flag", "structdvb__desc__t2__delivery.html#afc753a722bbdfa17eb7ab4c81abfdea1", null ],
    [ "plp_id", "structdvb__desc__t2__delivery.html#a81cdfda3f4dc79665df0c4415055bb14", null ],
    [ "reserved", "structdvb__desc__t2__delivery.html#abb28e16123cf08de69c0ebb748a5151c", null ],
    [ "SISO_MISO", "structdvb__desc__t2__delivery.html#a28f3833782eb1c28e156a53c3ed8df1e", null ],
    [ "subcel_info_loop_length", "structdvb__desc__t2__delivery.html#afd03d35dcc6f8d8f9cdcf5d88305d4fc", null ],
    [ "subcell", "structdvb__desc__t2__delivery.html#a81084af88ce9886652ca21178e5523d9", null ],
    [ "system_id", "structdvb__desc__t2__delivery.html#ac7542c02d52ccfc7b280760b5d0779eb", null ],
    [ "tfs_flag", "structdvb__desc__t2__delivery.html#a8e79b88229f401a7a35f3cb7a10009aa", null ],
    [ "transmission_mode", "structdvb__desc__t2__delivery.html#a87bd1e3f09dbbc3eabf9f9acb05473a0", null ]
];