var structdvb__device =
[
    [ "devices", "structdvb__device.html#abeb384f9fb1fb3a8b61d542f05432123", null ],
    [ "fe_parms", "structdvb__device.html#a7bdecdc55857d11baa6b76200737e695", null ],
    [ "num_devices", "structdvb__device.html#a95db66d7401506276e7ad5369d6b4087", null ]
];