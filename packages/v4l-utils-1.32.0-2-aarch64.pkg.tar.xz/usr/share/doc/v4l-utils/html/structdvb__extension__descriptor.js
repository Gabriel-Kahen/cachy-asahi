var structdvb__extension__descriptor =
[
    [ "descriptor", "structdvb__extension__descriptor.html#a68cc508cf614ce67170679d5a1d37308", null ],
    [ "extension_code", "structdvb__extension__descriptor.html#a0c50da5e0285f60382361eb5e26ca29c", null ],
    [ "length", "structdvb__extension__descriptor.html#ad5d07657d6ce7e3612053c0fe61e77e5", null ],
    [ "next", "structdvb__extension__descriptor.html#a41d0d24c32577025dc7ad630b96164fc", null ],
    [ "type", "structdvb__extension__descriptor.html#a76ee222e252c4bffa2430839beeac145", null ]
];