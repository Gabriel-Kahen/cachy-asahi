var structdvb__desc__event__extended__item =
[
    [ "description", "structdvb__desc__event__extended__item.html#a53d332536e8d921933cc8fb8a41e45d5", null ],
    [ "description_emph", "structdvb__desc__event__extended__item.html#abc497faa8dc2c0a5281d35ae305fc23d", null ],
    [ "item", "structdvb__desc__event__extended__item.html#a1a963e1f4d08ad78ccda264ae765619f", null ],
    [ "item_emph", "structdvb__desc__event__extended__item.html#ab826c1d26aeabfbbe28e37ba9d10864a", null ]
];