var structdvb__table__pat__program =
[
    [ "bitfield", "structdvb__table__pat__program.html#af367aebba1e4a0f056a64447c9c38593", null ],
    [ "next", "structdvb__table__pat__program.html#ae89f5e1a5d515bf6df292ab0f752ca44", null ],
    [ "pid", "structdvb__table__pat__program.html#ac3c37be3c192dc4e22c061f3153b12f3", null ],
    [ "reserved", "structdvb__table__pat__program.html#afe9b58b484c9a09f3d447198411b236d", null ],
    [ "service_id", "structdvb__table__pat__program.html#a6c96da9cb6e8b704ba13da6115567a21", null ]
];