var structdvb__desc__t2__delivery__subcell__old =
[
    [ "cell_id_extension", "structdvb__desc__t2__delivery__subcell__old.html#a85773dcddd593d07154c2199c56ba005", null ],
    [ "transposer_frequency", "structdvb__desc__t2__delivery__subcell__old.html#a0479a013f97a4352f00fd679d0e04191", null ]
];