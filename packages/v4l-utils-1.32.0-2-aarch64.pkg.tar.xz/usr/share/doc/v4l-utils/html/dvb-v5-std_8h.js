var dvb_v5_std_8h =
[
    [ "DTV_AUDIO_PID", "group__frontend.html#gaebb50fd66fd7824083f8a2c85e3eeba7", null ],
    [ "DTV_BER", "group__frontend.html#ga0a380404fc053ab72d8093a5acf60103", null ],
    [ "DTV_CH_NAME", "group__frontend.html#ga8e5ad40f65a7d620a32f182ffe39343f", null ],
    [ "DTV_COUNTRY_CODE", "group__frontend.html#ga2f32e16029dac63adb27066ca31092be", null ],
    [ "DTV_DISEQC_LNB", "group__frontend.html#gab83f42ae393f28d7a754e725fcab24f5", null ],
    [ "DTV_DISEQC_WAIT", "group__frontend.html#gab5416ba1e50dbae4920c45e02b7ca6e4", null ],
    [ "DTV_FREQ_BPF", "group__frontend.html#ga2f9ef2d7c18bb0d41cbda6bb7e076068", null ],
    [ "DTV_MAX_STAT_COMMAND", "group__frontend.html#gaddcdfb1573e0df65fafbab05f5470b45", null ],
    [ "DTV_MAX_USER_COMMAND", "group__frontend.html#ga87869ca15832145f9bd6b94c30fdd3aa", null ],
    [ "DTV_NUM_KERNEL_STATS", "group__frontend.html#gafce01ede7943ede2215a1fc8f4e90bf2", null ],
    [ "DTV_NUM_STATS_PROPS", "group__frontend.html#ga13252e390ff0550e0bff827523dc33bd", null ],
    [ "DTV_PER", "group__frontend.html#gaae80c2c97096e7cfbf5a8c2de5eb5001", null ],
    [ "DTV_PLS_CODE", "group__frontend.html#ga58dcf75eb5cb6ccbb71c56b0c55386ed", null ],
    [ "DTV_PLS_MODE", "group__frontend.html#ga5e889b20ef56ee37df277047f7553135", null ],
    [ "DTV_POLARIZATION", "group__frontend.html#gab68f6a50e08763b54317cd234b625afc", null ],
    [ "DTV_PRE_BER", "group__frontend.html#gade8a86029dae354c98ce75825fff8f37", null ],
    [ "DTV_QUALITY", "group__frontend.html#gaa73136f5485832d7094d3cad6885798c", null ],
    [ "DTV_SAT_NUMBER", "group__frontend.html#gadc69806e6e6365c85dba8b6aabbe1eb2", null ],
    [ "DTV_SERVICE_ID", "group__frontend.html#gab5829fcdd1b0d8d4da9aed19be6efe46", null ],
    [ "DTV_STAT_COMMAND_START", "group__frontend.html#ga12e411fb91f605a8138edca11a1a8408", null ],
    [ "DTV_STAT_NAME_SIZE", "group__frontend.html#gab3a5fd4cad7c84e6ef44166fe4d69dfd", null ],
    [ "DTV_STATUS", "group__frontend.html#ga6b9d1ac1e7f098f2e189408c573957a1", null ],
    [ "DTV_USER_COMMAND_START", "group__frontend.html#gaac44db37fdcadc57f7b13b7756486923", null ],
    [ "DTV_USER_NAME_SIZE", "group__frontend.html#ga6305be8c010db11ab223b947d7f3e50e", null ],
    [ "DTV_VCHANNEL", "group__frontend.html#gaa80dac4eb7eff45f4cbf90e61b168a9f", null ],
    [ "DTV_VIDEO_PID", "group__frontend.html#gaa83750f7305090c419784e78d6275c49", null ],
    [ "dvb_quality", "group__frontend.html#ga7eccef04635a4b32d251e0fa9fe43a97", [
      [ "DVB_QUAL_UNKNOWN", "dvb-v5-std_8h.html#ga7eccef04635a4b32d251e0fa9fe43a97a5d7dac7c1ae946e063e4674c41ff499c", null ],
      [ "DVB_QUAL_POOR", "dvb-v5-std_8h.html#ga7eccef04635a4b32d251e0fa9fe43a97af370ea1484e641aad1edb197f8f92dc0", null ],
      [ "DVB_QUAL_OK", "dvb-v5-std_8h.html#ga7eccef04635a4b32d251e0fa9fe43a97ab019fe5c846dbad645b63788eda873ec", null ],
      [ "DVB_QUAL_GOOD", "dvb-v5-std_8h.html#ga7eccef04635a4b32d251e0fa9fe43a97a5118d9312ce9b60af3c4d53a91d11642", null ]
    ] ],
    [ "dvb_sat_polarization", "group__satellite.html#ga6010ef4a66faa5ca7d3baf0075c019e7", [
      [ "POLARIZATION_OFF", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7ad483ddd6e893d8e069f3bb98fb2ab775", null ],
      [ "POLARIZATION_H", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7acd596b91e205ca9bb9cd32d4f6937f7e", null ],
      [ "POLARIZATION_V", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7a4d2bd2c3be3d6ccf68db5cc8d803fb08", null ],
      [ "POLARIZATION_L", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7ae5a87f0b3c42c6fe16b44bce403a904a", null ],
      [ "POLARIZATION_R", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7a2cbc3a93ac7b093d489649efd38e3d6e", null ]
    ] ]
];