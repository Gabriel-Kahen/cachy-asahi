var structatsc__desc__service__location__elementary =
[
    [ "bitfield", "structatsc__desc__service__location__elementary.html#a8d359c33d22b8cfdf221f51aec21809e", null ],
    [ "elementary_pid", "structatsc__desc__service__location__elementary.html#aede01d15a735ec038a980b3f076ed5bc", null ],
    [ "ISO_639_language_code", "structatsc__desc__service__location__elementary.html#a62e3cd6875d645435552a1ddb4d6601a", null ],
    [ "reserved", "structatsc__desc__service__location__elementary.html#ae9cbfe5ba3aea5b8bb352524f4d01eeb", null ],
    [ "stream_type", "structatsc__desc__service__location__elementary.html#a700f1fe52545132db46789a06baa791a", null ]
];