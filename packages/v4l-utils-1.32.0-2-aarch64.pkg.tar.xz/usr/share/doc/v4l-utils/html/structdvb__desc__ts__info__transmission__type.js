var structdvb__desc__ts__info__transmission__type =
[
    [ "num_of_service", "structdvb__desc__ts__info__transmission__type.html#a4345264e94f874594c9bbac11e5e6fac", null ],
    [ "transmission_type_info", "structdvb__desc__ts__info__transmission__type.html#a794305cc2e400c00a5710672b9a0c037", null ]
];