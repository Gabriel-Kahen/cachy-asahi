var structdvb__dev__list =
[
    [ "bus_addr", "structdvb__dev__list.html#a15413bc2c628b2800f403a857e19495f", null ],
    [ "bus_id", "structdvb__dev__list.html#a61f21a0ebeec23821258051864abf892", null ],
    [ "dvb_type", "structdvb__dev__list.html#a20a9c7d7de8b7d35fe70a6a33725d503", null ],
    [ "manufacturer", "structdvb__dev__list.html#ad96647c75f85e795704708c8acc8c613", null ],
    [ "path", "structdvb__dev__list.html#ad1780dde3dd0ef85d7cc3b80967cf740", null ],
    [ "product", "structdvb__dev__list.html#a733a45940f2936862ce8b0531e850ffd", null ],
    [ "serial", "structdvb__dev__list.html#a4b1cbe0b796488f42e117aeebdfe0ee4", null ],
    [ "sysname", "structdvb__dev__list.html#ab8dddb061b9f9b2f3c758802880b538f", null ],
    [ "syspath", "structdvb__dev__list.html#a2930d26c660a0515eda6fb28b55ad88d", null ]
];