var structisdb__partial__reception__service__id =
[
    [ "service_id", "structisdb__partial__reception__service__id.html#a3211e0330325b990c6a266501156369c", null ]
];