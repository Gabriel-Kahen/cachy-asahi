var structdvb__v5__fe__parms =
[
    [ "abort", "structdvb__v5__fe__parms.html#a189e9ea2b61c593ec9f001b0a6925b89", null ],
    [ "current_sys", "structdvb__v5__fe__parms.html#af528ac7420efd3b29f4dfa456ee791ea", null ],
    [ "default_charset", "structdvb__v5__fe__parms.html#a95f6ff7f8d5c56d33c2683348d921cbf", null ],
    [ "diseqc_wait", "structdvb__v5__fe__parms.html#a7904d056b88d48c39c8fef242b963539", null ],
    [ "freq_bpf", "structdvb__v5__fe__parms.html#a304dc4d27ecfea9095ce292c8af7ae8a", null ],
    [ "has_v5_stats", "structdvb__v5__fe__parms.html#a4236b34fbde5c0bb52ea340b52c7cdae", null ],
    [ "info", "structdvb__v5__fe__parms.html#ab5999cab0a0706572eb2e4dc0d9ec939", null ],
    [ "legacy_fe", "structdvb__v5__fe__parms.html#a0c45cac03a5531547470501f75627edf", null ],
    [ "lna", "structdvb__v5__fe__parms.html#a0a61f74a8d249a678e23068d92c28759", null ],
    [ "lnb", "structdvb__v5__fe__parms.html#ad9d556f33c37541df2b6277edd5ef9ab", null ],
    [ "logfunc", "structdvb__v5__fe__parms.html#ad2bb3ac5cfd12c88a216ce686ed32249", null ],
    [ "num_systems", "structdvb__v5__fe__parms.html#a7bfb07317e3f68ec8a5a4d4930427517", null ],
    [ "output_charset", "structdvb__v5__fe__parms.html#ac9e9f5257d54e6a9e4958282c716d77f", null ],
    [ "sat_number", "structdvb__v5__fe__parms.html#a96c8ea5eb5ae3a69671af245efab7dd9", null ],
    [ "systems", "structdvb__v5__fe__parms.html#acddda034e583c9563bfc02a7289c26c1", null ],
    [ "verbose", "structdvb__v5__fe__parms.html#a907df1b9fd524cfb0d99ed9e50ccf799", null ],
    [ "version", "structdvb__v5__fe__parms.html#ae17515452599996f08a0d8c8f85c5439", null ]
];