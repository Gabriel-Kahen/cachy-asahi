var structdvb__file =
[
    [ "first_entry", "structdvb__file.html#aa3487d57118a69c5dc113c8c6512a9d5", null ],
    [ "fname", "structdvb__file.html#aca7f0535c4976e99581b75859441cd4c", null ],
    [ "n_entries", "structdvb__file.html#a042a1f28068897a9fe8d9f54bfbdefa1", null ]
];