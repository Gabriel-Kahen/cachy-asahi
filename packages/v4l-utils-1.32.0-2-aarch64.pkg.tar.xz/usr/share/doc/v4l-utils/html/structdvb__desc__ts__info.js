var structdvb__desc__ts__info =
[
    [ "bitfield", "structdvb__desc__ts__info.html#ad9597fa4390b9c7621b78cc94fb8dab8", null ],
    [ "length", "structdvb__desc__ts__info.html#a54933f2714b23fc5a8a5ac7d24f37912", null ],
    [ "length_of_ts_name", "structdvb__desc__ts__info.html#a5da2be8fff1058897a2f886186b1d15f", null ],
    [ "next", "structdvb__desc__ts__info.html#ac8066dc09c8683ca85ebb9d3040a54b1", null ],
    [ "remote_control_key_id", "structdvb__desc__ts__info.html#afb57a484c1623e3f6d1e5e0d4fb64e2b", null ],
    [ "service_id", "structdvb__desc__ts__info.html#a4fc1eab2ba94b29a1bee34ef22f70213", null ],
    [ "transmission_type", "structdvb__desc__ts__info.html#a5894a89baba74f87ee72ca92f9a019be", null ],
    [ "transmission_type_count", "structdvb__desc__ts__info.html#a63ec0d9ff02b4356500c42034a9d417d", null ],
    [ "ts_name", "structdvb__desc__ts__info.html#a82646c69c78eecbdc633aefb8226c4fa", null ],
    [ "ts_name_emph", "structdvb__desc__ts__info.html#a6e17bd6319f1fa5c1bb2f6b53854a0fc", null ],
    [ "type", "structdvb__desc__ts__info.html#a03b209110e30dc0800503f4d1bd3ed62", null ]
];