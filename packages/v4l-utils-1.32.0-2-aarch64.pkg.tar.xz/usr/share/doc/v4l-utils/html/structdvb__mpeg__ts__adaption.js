var structdvb__mpeg__ts__adaption =
[
    [ "data", "structdvb__mpeg__ts__adaption.html#a0c83443cd51a5427c4c3796e95179b13", null ],
    [ "discontinued", "structdvb__mpeg__ts__adaption.html#abd08175d2a4d25234937e7200af10d3a", null ],
    [ "extension", "structdvb__mpeg__ts__adaption.html#a03c0190fdafe60a9a81f7dc6249fb7f1", null ],
    [ "length", "structdvb__mpeg__ts__adaption.html#af78040e5e25af53d299c76eab74f4b68", null ],
    [ "OPCR", "structdvb__mpeg__ts__adaption.html#a5ccecc55b313f9c13ea483b0914c4463", null ],
    [ "PCR", "structdvb__mpeg__ts__adaption.html#a7e8e0a32623c4ca7fdf065df63b0cb7f", null ],
    [ "priority", "structdvb__mpeg__ts__adaption.html#aa90965640a300b9e354bfb6348519018", null ],
    [ "private_data", "structdvb__mpeg__ts__adaption.html#a2b16ea60e3e8b56c7fdd2a9caa4087d9", null ],
    [ "random_access", "structdvb__mpeg__ts__adaption.html#a22cc487c29c02fb45233c59d4feec336", null ],
    [ "splicing_point", "structdvb__mpeg__ts__adaption.html#a45663fef6132a439cd05ad00addc5f40", null ]
];