var unionatsc__table__eit__desc__length =
[
    [ "bitfield", "unionatsc__table__eit__desc__length.html#aca8470d97bfe43ab9621a639966e3eae", null ],
    [ "desc_length", "unionatsc__table__eit__desc__length.html#a829f3d2c259290eb89b3f2b34ac62ec1", null ],
    [ "reserved", "unionatsc__table__eit__desc__length.html#ad79aca5254793936efca8fb7748102dd", null ]
];