var structdvb__table__eit__event =
[
    [ "bitfield1", "structdvb__table__eit__event.html#a0ba75a5ab01f9410b6b1ba9bd2025848", null ],
    [ "bitfield2", "structdvb__table__eit__event.html#af9d58c5da5ed7ff8e30238ea6feba01d", null ],
    [ "desc_length", "structdvb__table__eit__event.html#afc3f0c5ffb62e8a701f62ccb08aed8c7", null ],
    [ "descriptor", "structdvb__table__eit__event.html#a74dce98d79908589e0cab48826abc608", null ],
    [ "duration", "structdvb__table__eit__event.html#a36385bc0a95110919e387ccad824a85f", null ],
    [ "dvbduration", "structdvb__table__eit__event.html#a652d2ee15251e3dd9826115c75639591", null ],
    [ "dvbstart", "structdvb__table__eit__event.html#a5dbcde49622aa7aaf77e8b48ca278b50", null ],
    [ "event_id", "structdvb__table__eit__event.html#a75f8131efb2d346a9365395b3da8e598", null ],
    [ "free_CA_mode", "structdvb__table__eit__event.html#a225e66107c9d387aa1f322b234755f41", null ],
    [ "next", "structdvb__table__eit__event.html#aaa32e92799bce93f8d5e5ad7b5554fc5", null ],
    [ "running_status", "structdvb__table__eit__event.html#a69e2b215d5720ec04aebc72036434682", null ],
    [ "service_id", "structdvb__table__eit__event.html#aa8c76144d29b453dca7f078fb669568d", null ],
    [ "start", "structdvb__table__eit__event.html#a841da7d44fc83b2a4d8490c57d1e7067", null ]
];