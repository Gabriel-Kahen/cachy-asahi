var desc__language_8h =
[
    [ "dvb_desc_language_init", "group__descriptors.html#gab2969b1faefccdd7dbcf20ab8995e61a", null ],
    [ "dvb_desc_language_print", "group__descriptors.html#ga65b275f8e046368e21cb467c447ba671", null ]
];