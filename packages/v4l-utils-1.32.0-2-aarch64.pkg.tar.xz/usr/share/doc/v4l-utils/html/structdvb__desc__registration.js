var structdvb__desc__registration =
[
    [ "additional_identification_info", "structdvb__desc__registration.html#ac3e2a56746f7cec64d29650c15db1b3e", null ],
    [ "format_identifier", "structdvb__desc__registration.html#ae384c9942df4af62d137f1f7d5e97ae0", null ],
    [ "length", "structdvb__desc__registration.html#a61a3691d367c8e5fe57402753eb97745", null ],
    [ "next", "structdvb__desc__registration.html#a9ebb6ca2c12f18aae652e6c9a5451356", null ],
    [ "type", "structdvb__desc__registration.html#a8150a0a14f43f4ad7fb1d8d826b476a1", null ]
];