var structdvb__desc__sat =
[
    [ "bitfield", "structdvb__desc__sat.html#aaf15dae6167b55379c9a4162166f9257", null ],
    [ "fec", "structdvb__desc__sat.html#a99af4c247b9711fbe58228a8c346bc55", null ],
    [ "frequency", "structdvb__desc__sat.html#a387724bf2f7cc6acdb7ad347820ca1cc", null ],
    [ "length", "structdvb__desc__sat.html#ae5b489dea0c6edad2bf8bb88086708ff", null ],
    [ "modulation_system", "structdvb__desc__sat.html#aeb4c74705249ffaa87fc9dd587f7042a", null ],
    [ "modulation_type", "structdvb__desc__sat.html#a3db0bc387376ebe4b66d5f4faf4d9bf8", null ],
    [ "next", "structdvb__desc__sat.html#ab81809d9f37a5af0fd8d37e54ad4d146", null ],
    [ "orbit", "structdvb__desc__sat.html#af886102a0e8dbc1db515e2b04a058f84", null ],
    [ "polarization", "structdvb__desc__sat.html#a2dd30fa3178bb9aec6aad8cc7952a5f8", null ],
    [ "roll_off", "structdvb__desc__sat.html#a48dc77f7884cb63827c85bc1e54d22a4", null ],
    [ "symbol_rate", "structdvb__desc__sat.html#a8945bdebbe0e4b6c008e19d704216fea", null ],
    [ "type", "structdvb__desc__sat.html#a859e70694255ef1f5efed3298b7c25e7", null ],
    [ "west_east", "structdvb__desc__sat.html#a9970c50ddcda01bf1a26f3010743fd32", null ]
];