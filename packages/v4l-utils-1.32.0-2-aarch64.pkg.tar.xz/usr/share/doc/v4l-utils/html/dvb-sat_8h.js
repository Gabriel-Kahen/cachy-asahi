var dvb_sat_8h =
[
    [ "dvb_sat_lnb::dvbsat_freqrange", "structdvb__sat__lnb_1_1dvbsat__freqrange.html", "structdvb__sat__lnb_1_1dvbsat__freqrange" ],
    [ "dvb_print_all_lnb", "group__satellite.html#ga331da0c0d4a550eb197a9cde59130c1e", null ],
    [ "dvb_print_lnb", "group__satellite.html#ga7662df9e20b4d2e1c8f1bebb3b347fd7", null ],
    [ "dvb_sat_get_lnb", "group__satellite.html#gaaa68df35cf1bd980ad8b96d9867d65b7", null ],
    [ "dvb_sat_get_lnb_name", "group__satellite.html#gad39f91119ebf9cc234b569c8e51425bc", null ],
    [ "dvb_sat_real_freq", "group__satellite.html#gad932fc845fcbd4ab1ecdd230267a1b1f", null ],
    [ "dvb_sat_search_lnb", "group__satellite.html#gac9cde4ada62dd033cdbc189835c620c7", null ],
    [ "dvb_sat_set_parms", "group__satellite.html#gad5db6978b0b5886968a372f7334c5236", null ]
];