var structdvb__desc__event__short =
[
    [ "language", "structdvb__desc__event__short.html#aaab10f2b6d68efb0540250a249ceb959", null ],
    [ "length", "structdvb__desc__event__short.html#a13d8d765743ab6ea58bedde21779b8a5", null ],
    [ "name", "structdvb__desc__event__short.html#a37bb5b4509544beab1500696daaf6186", null ],
    [ "name_emph", "structdvb__desc__event__short.html#a30a05b49ca3edd59c7e495a889176b74", null ],
    [ "next", "structdvb__desc__event__short.html#adafffc31c4cb01bc1e3323143cd80051", null ],
    [ "text", "structdvb__desc__event__short.html#a37d8dc60ad5337847f144af725d7b7d3", null ],
    [ "text_emph", "structdvb__desc__event__short.html#aaffb72080171f85aae652c83b8a79d4c", null ],
    [ "type", "structdvb__desc__event__short.html#a281f8b025b70b9a69148ddccae42f096", null ]
];