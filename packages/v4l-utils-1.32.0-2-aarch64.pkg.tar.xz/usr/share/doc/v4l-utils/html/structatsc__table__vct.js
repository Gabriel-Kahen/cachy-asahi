var structatsc__table__vct =
[
    [ "channel", "structatsc__table__vct.html#a8483490019a703f071bdf34e4bbee899", null ],
    [ "descriptor", "structatsc__table__vct.html#ad059e33259419eb187183d7b4317a3bd", null ],
    [ "header", "structatsc__table__vct.html#a1dcd77e83bf34af20417f9284b0bb63b", null ],
    [ "num_channels_in_section", "structatsc__table__vct.html#aa77f5b5ad2b6559a5fbb7c2deee0326a", null ],
    [ "protocol_version", "structatsc__table__vct.html#a1512fe21f9c8b7ddc12dcf4d6a3c2bbd", null ]
];