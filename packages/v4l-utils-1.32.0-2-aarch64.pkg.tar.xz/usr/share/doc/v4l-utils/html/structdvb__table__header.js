var structdvb__table__header =
[
    [ "bitfield", "structdvb__table__header.html#afb50087835bdd55b1defbcf61bc14d7f", null ],
    [ "current_next", "structdvb__table__header.html#aebd2284504601c0a51ed0a8753189bd4", null ],
    [ "id", "structdvb__table__header.html#a7dc1b35a1ab039e567d576a964b2c7e2", null ],
    [ "last_section", "structdvb__table__header.html#aedb16ff4dfb188799bb5c23740bd43a7", null ],
    [ "one", "structdvb__table__header.html#aa48a6e5036f14b6340cf3b076252574c", null ],
    [ "one2", "structdvb__table__header.html#acb0b0c422319b1cbc312d8e01d491568", null ],
    [ "section_id", "structdvb__table__header.html#a02100fa04e7116b957307fec8ee7a070", null ],
    [ "section_length", "structdvb__table__header.html#ac9f0dbfd8eff9c236690f1c9076c24c7", null ],
    [ "syntax", "structdvb__table__header.html#a60e0ee5aabd15b24fc792cc35d15304e", null ],
    [ "table_id", "structdvb__table__header.html#ae1cc7f1d362c22ed476276bd4181c0dc", null ],
    [ "version", "structdvb__table__header.html#a6547455af08bfb8a240a7aee425922bb", null ],
    [ "zero", "structdvb__table__header.html#a3fa8369a352c3691034ac24ac6e08961", null ]
];