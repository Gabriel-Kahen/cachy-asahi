var desc__network__name_8h =
[
    [ "dvb_desc_network_name_free", "group__descriptors.html#ga7d7c93491989b7c021553019e9c4a02d", null ],
    [ "dvb_desc_network_name_init", "group__descriptors.html#ga9a7a37e550682b9b762448c251ab2b47", null ],
    [ "dvb_desc_network_name_print", "group__descriptors.html#gaca5fbb97a417b7ef37fa82f272348971", null ]
];