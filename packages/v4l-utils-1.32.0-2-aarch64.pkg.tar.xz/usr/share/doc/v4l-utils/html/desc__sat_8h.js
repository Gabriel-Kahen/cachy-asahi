var desc__sat_8h =
[
    [ "dvb_desc_sat_init", "group__descriptors.html#ga094b5557c45c96e93cd253323c2ddddd", null ],
    [ "dvb_desc_sat_print", "group__descriptors.html#ga0d7dd274aeb677d3fd366b75a4828b01", null ],
    [ "dvbs_dvbc_dvbs_freq_inner", "desc__sat_8h.html#a5220229dae3bcb8ad577ace4ebd20834", null ],
    [ "dvbs_modulation", "desc__sat_8h.html#a14bfa509714124a7e34e2f4eb5dd6678", null ],
    [ "dvbs_polarization", "desc__sat_8h.html#a5bcb5f78c7dae1d79c803702a4a1836f", null ],
    [ "dvbs_rolloff", "desc__sat_8h.html#ab0c75ca6dc94aa23acd5bde113260ec9", null ]
];