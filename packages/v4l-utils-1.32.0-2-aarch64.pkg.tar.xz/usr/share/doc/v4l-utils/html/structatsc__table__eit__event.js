var structatsc__table__eit__event =
[
    [ "__pad0__", "structatsc__table__eit__event.html#a130dc311136b1eac1c5b38cd2566fec6", null ],
    [ "bitfield", "structatsc__table__eit__event.html#a925ef144011d725800f7efa8e4599ebf", null ],
    [ "bitfield2", "structatsc__table__eit__event.html#a34a04affc08bdd558672a854b4d930ae", null ],
    [ "descriptor", "structatsc__table__eit__event.html#a8faf3e59b1005e93117acf161d5a9981", null ],
    [ "duration", "structatsc__table__eit__event.html#a1d94e9df14f885c449f420eefcdae88a", null ],
    [ "etm", "structatsc__table__eit__event.html#a7bed550d642ccb219162016ab2afc61a", null ],
    [ "event_id", "structatsc__table__eit__event.html#a11379e0e1b9bd6c97dbf3d34a9c71823", null ],
    [ "next", "structatsc__table__eit__event.html#a41b95feadb05dba86ccb847e3b7741fd", null ],
    [ "one", "structatsc__table__eit__event.html#a69deff0bdeff5bf8f71cac754da00fb5", null ],
    [ "one2", "structatsc__table__eit__event.html#a4ac495e28c4cc0ae81198524c5bd0c2b", null ],
    [ "source_id", "structatsc__table__eit__event.html#a13a1f7f6a330addee09de4fae0bcf7f4", null ],
    [ "start", "structatsc__table__eit__event.html#ad6376e190ef2a2be1603331c94e36ea0", null ],
    [ "start_time", "structatsc__table__eit__event.html#ac2040df9e17ddc12f9b99196e741c5b8", null ],
    [ "title_length", "structatsc__table__eit__event.html#a25ddec226c5a9d20468d8f3961d1ce2c", null ]
];