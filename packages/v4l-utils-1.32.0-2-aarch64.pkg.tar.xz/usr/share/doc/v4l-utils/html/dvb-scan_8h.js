var dvb_scan_8h =
[
    [ "MAX_TABLE_SIZE", "dvb-scan_8h.html#a48d3ccc21ddc04633ef7cd7e80dbb987", null ],
    [ "check_frontend_t", "group__frontend__scan.html#ga587de9d74f646436b1cf58c37236a007", null ],
    [ "dvb_add_scaned_transponders", "group__frontend__scan.html#gac172e2cb90570677b87e3e83c97dc61b", null ],
    [ "dvb_free_ts_tables", "group__frontend__scan.html#ga00661faadb82379c4c2efe267d046970", null ],
    [ "dvb_get_ts_tables", "group__frontend__scan.html#ga354e611b9e5ebdf3590005a78e139d35", null ],
    [ "dvb_read_section", "group__frontend__scan.html#ga956af98a11484d5296abe1668f9485c4", null ],
    [ "dvb_read_section_with_id", "group__frontend__scan.html#gab8938c61f97571d01e3608ff52c4e092", null ],
    [ "dvb_read_sections", "group__frontend__scan.html#gaf274aa17abefce824e5c4a2a8e082c4d", null ],
    [ "dvb_scan_alloc_handler_table", "group__frontend__scan.html#gafe8aa25bcaaeddfc8b0677bca4312655", null ],
    [ "dvb_scan_free_handler_table", "group__frontend__scan.html#gad83553d5b779c63dff7a6dda4348cc19", null ],
    [ "dvb_scan_transponder", "group__frontend__scan.html#ga2c7f3f53c56ee83cb73c922c84398de9", null ],
    [ "dvb_table_filter_free", "group__frontend__scan.html#ga0bd956908517ea2d53ad2de62df7247c", null ]
];