var structdvb__desc__event__extended =
[
    [ "id", "structdvb__desc__event__extended.html#aeac0a0a76cfcb850dac3a6561747ea1b", null ],
    [ "ids", "structdvb__desc__event__extended.html#a5399da3fb0ebe478d3df4f07e5e81754", null ],
    [ "items", "structdvb__desc__event__extended.html#ab2f25e7ad947bc72f03017295213e4cd", null ],
    [ "language", "structdvb__desc__event__extended.html#abfebd0fca0b27ee354f2b6465ad617ef", null ],
    [ "last_id", "structdvb__desc__event__extended.html#a1ead068bead6c498770ed2d317902de2", null ],
    [ "length", "structdvb__desc__event__extended.html#a4b3a944a1fd7c140cdc065ae4af6ffc1", null ],
    [ "next", "structdvb__desc__event__extended.html#a814a2c7efe2b35079414e6675f207ae6", null ],
    [ "num_items", "structdvb__desc__event__extended.html#a1fcbdbd71833e851c47ec2d84b6fdde0", null ],
    [ "text", "structdvb__desc__event__extended.html#aa4cb4dea2796cc68b97d9b4ec7dbf854", null ],
    [ "text_emph", "structdvb__desc__event__extended.html#ad9bac488f68fe025ff7c37155f72f613", null ],
    [ "type", "structdvb__desc__event__extended.html#a13eb177fc2be1586a0d9bc184d459baf", null ]
];