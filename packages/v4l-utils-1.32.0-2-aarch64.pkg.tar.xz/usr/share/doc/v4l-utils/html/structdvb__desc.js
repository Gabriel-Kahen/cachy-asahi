var structdvb__desc =
[
    [ "data", "structdvb__desc.html#a343cb865c21165cabe40604e3ab50dab", null ],
    [ "length", "structdvb__desc.html#a8b958e68850a29783a8670d57fdc77d8", null ],
    [ "next", "structdvb__desc.html#ad9537b0c351075e86a6c1a291cb3618e", null ],
    [ "type", "structdvb__desc.html#a2263f3e4ec431485208aecfa5ad1a267", null ]
];