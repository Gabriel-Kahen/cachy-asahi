var structdvb__elementary__pid =
[
    [ "pid", "structdvb__elementary__pid.html#a056e208bb2752181c5fc8d823dabe1a7", null ],
    [ "type", "structdvb__elementary__pid.html#a12da494504a547138f2f01581818d59a", null ]
];