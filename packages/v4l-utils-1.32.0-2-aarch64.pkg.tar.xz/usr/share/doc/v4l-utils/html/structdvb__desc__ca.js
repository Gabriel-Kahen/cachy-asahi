var structdvb__desc__ca =
[
    [ "bitfield1", "structdvb__desc__ca.html#aee4c9e119e96ebf146a95b51a5d9e0e9", null ],
    [ "ca_id", "structdvb__desc__ca.html#ac8b74b388e3cc4c844f8830144353ca1", null ],
    [ "ca_pid", "structdvb__desc__ca.html#acbde18a44c1fd21bfb313cdf68fafe60", null ],
    [ "length", "structdvb__desc__ca.html#a3cd50e56d28449b543c8d55a667dc21e", null ],
    [ "next", "structdvb__desc__ca.html#aca8e3e619b44250c3a9d92a355c6b21a", null ],
    [ "privdata", "structdvb__desc__ca.html#aa6351680970b4336b0deea4eef066d49", null ],
    [ "privdata_len", "structdvb__desc__ca.html#aefe71f126559cc6927bc5f015c9b42ad", null ],
    [ "reserved", "structdvb__desc__ca.html#acbc81fea756b8fb5f2a324bf43565dee", null ],
    [ "type", "structdvb__desc__ca.html#a4c21989ac055eda323de69748ed03b9e", null ]
];