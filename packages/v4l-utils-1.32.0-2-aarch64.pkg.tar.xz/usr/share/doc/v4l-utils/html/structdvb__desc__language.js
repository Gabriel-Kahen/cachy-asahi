var structdvb__desc__language =
[
    [ "audio_type", "structdvb__desc__language.html#a1181e57871176b64b9cd70cf9a5ac629", null ],
    [ "language", "structdvb__desc__language.html#abcc6e011932cb66be688aa881f63d8e8", null ],
    [ "length", "structdvb__desc__language.html#a140f572e1f91590745e6226b43d3e5c7", null ],
    [ "next", "structdvb__desc__language.html#ac4cb1bdc5e6a1eae9dd666cb3b60ffb0", null ],
    [ "type", "structdvb__desc__language.html#a4cbbc3b7acc36562bb6d9e6745d035fe", null ]
];