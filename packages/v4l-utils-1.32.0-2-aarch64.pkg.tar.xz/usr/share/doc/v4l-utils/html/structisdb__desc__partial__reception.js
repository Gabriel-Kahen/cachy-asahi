var structisdb__desc__partial__reception =
[
    [ "length", "structisdb__desc__partial__reception.html#abc0d3f5cc3523e0b013c28ea62ba7cef", null ],
    [ "next", "structisdb__desc__partial__reception.html#a4c3186505f480a211514dfa1b0a3660b", null ],
    [ "partial_reception", "structisdb__desc__partial__reception.html#ad16cc8f1813103b5689990f13a502f9c", null ],
    [ "type", "structisdb__desc__partial__reception.html#a6840335ba9d8183d36dbebb25744bfa8", null ]
];