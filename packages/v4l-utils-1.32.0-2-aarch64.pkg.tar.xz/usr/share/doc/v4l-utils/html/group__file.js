var group__file =
[
    [ "dvb-file.h", "dvb-file_8h.html", null ],
    [ "dvb_elementary_pid", "structdvb__elementary__pid.html", [
      [ "pid", "structdvb__elementary__pid.html#a056e208bb2752181c5fc8d823dabe1a7", null ],
      [ "type", "structdvb__elementary__pid.html#a12da494504a547138f2f01581818d59a", null ]
    ] ],
    [ "dvb_entry", "structdvb__entry.html", [
      [ "audio_pid", "structdvb__entry.html#a43222f11e4a5788718a2e2e789c546f1", null ],
      [ "audio_pid_len", "structdvb__entry.html#a139e5b83d0100cdbbc9e66b2419b2878", null ],
      [ "channel", "structdvb__entry.html#a95383462df05b5055212999cfb9af2fc", null ],
      [ "diseqc_wait", "structdvb__entry.html#a452a8ca6d2a09383c369a1374467d543", null ],
      [ "freq_bpf", "structdvb__entry.html#ace8a3953d73917a7907297a89e92b73e", null ],
      [ "lnb", "structdvb__entry.html#a16545c27b357e3144c04a224e9e61278", null ],
      [ "location", "structdvb__entry.html#a269704d91ab79839bae28e5466133f17", null ],
      [ "n_props", "structdvb__entry.html#a37594dfcb911f719a590f012f732ed53", null ],
      [ "network_id", "structdvb__entry.html#a7f000408b55a5e5499ca2cbc95140b5c", null ],
      [ "next", "structdvb__entry.html#ab36ec69e316a685f2527cb2f2820cfe3", null ],
      [ "other_el_pid", "structdvb__entry.html#a39e89bf2b7045a0b2a38ce9da9857e03", null ],
      [ "other_el_pid_len", "structdvb__entry.html#a5daff6ffb17b970d2add0c1ac1d69870", null ],
      [ "props", "structdvb__entry.html#a38b8ff1806fed84a71b167f269a83bcf", null ],
      [ "sat_number", "structdvb__entry.html#ad2ead2bf639f720fa3589718e623b4b6", null ],
      [ "service_id", "structdvb__entry.html#aa8675380605ed6bdddb4d5ccce263a5b", null ],
      [ "transport_id", "structdvb__entry.html#a9ce250e50e2d8eb50358ffa744e9daf0", null ],
      [ "vchannel", "structdvb__entry.html#ae811cc0a7088eaaa18c5a834e6a51d2f", null ],
      [ "video_pid", "structdvb__entry.html#a3d47b2030b0d018e142915631362a030", null ],
      [ "video_pid_len", "structdvb__entry.html#a4e3d53068d94826d7214bbd0bb4317c9", null ]
    ] ],
    [ "dvb_parse_table", "structdvb__parse__table.html", [
      [ "default_value", "structdvb__parse__table.html#ad4894974c29f249d7a80de3044e47fdc", null ],
      [ "has_default_value", "structdvb__parse__table.html#a3e348834f269a5f8f41e6b81d690bb55", null ],
      [ "mult_factor", "structdvb__parse__table.html#ab6c6d265130aa3c5df772e5d41a50a9b", null ],
      [ "prop", "structdvb__parse__table.html#a2915bf2960363630682aad318d547ef6", null ],
      [ "size", "structdvb__parse__table.html#ab54e40f42c4e21f38f0e577637eadc49", null ],
      [ "table", "structdvb__parse__table.html#a7529877ea0eed58c261e470aa953e749", null ]
    ] ],
    [ "dvb_parse_struct", "structdvb__parse__struct.html", [
      [ "delsys", "structdvb__parse__struct.html#a602118dd77afc244b83145b06e5986dd", null ],
      [ "id", "structdvb__parse__struct.html#a136c366426e79d161318e5fd9fd9d03a", null ],
      [ "size", "structdvb__parse__struct.html#a05c5e02000634b8b5e2d3f2713a85242", null ],
      [ "table", "structdvb__parse__struct.html#a8fcfa39dbab86b36eaba525ada96ef77", null ]
    ] ],
    [ "dvb_file_formats", "group__file.html#ga189e923df3b573ee1881bcd2a1329e36", [
      [ "FILE_UNKNOWN", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a45cc741894b5757bae82fc08347264da", null ],
      [ "FILE_ZAP", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a364cd1d59248ff1e44e91dbd3a93f9c0", null ],
      [ "FILE_CHANNEL", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a232712daadb94d4736ee6c2e413f9b0d", null ],
      [ "FILE_DVBV5", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a6f92d4e99e0a29112a3d3d908fc85490", null ],
      [ "FILE_VDR", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a9a682da8d7acc8581a8b3b3fc21bae1b", null ]
    ] ],
    [ "dvb_file_free", "group__file.html#ga5dfc7d72e44db45d235f267d7fb8bc70", null ],
    [ "dvb_parse_delsys", "group__file.html#gafd50356ff0c41ccdeb560c7c447f2526", null ],
    [ "dvb_parse_format", "group__file.html#gacfdc20d393ac4b0db8e830190491b506", null ],
    [ "dvb_parse_format_oneline", "group__file.html#ga5f02dc00b22235e99c50a0ceaf90a644", null ],
    [ "dvb_read_file", "group__file.html#gaa67c7236b7899f8dae5ff9c5a48c5225", null ],
    [ "dvb_read_file_format", "group__file.html#ga22160bafdc84d98663baf1c90f3080bd", null ],
    [ "dvb_retrieve_entry_prop", "group__file.html#ga45a0eea4649d09766b0d77f35f08bb0e", null ],
    [ "dvb_store_channel", "group__file.html#ga96968d8eae65990dd259f150f2a12aa6", null ],
    [ "dvb_store_entry_prop", "group__file.html#ga68e600a22d550f7c0e4a1c7d1c2f79cc", null ],
    [ "dvb_write_file", "group__file.html#gaec6ac24d9aaf7274b1a99ff9f5760ee2", null ],
    [ "dvb_write_file_format", "group__file.html#ga4e806ba940ac5498d9e2d04b0659b855", null ],
    [ "dvb_write_format_oneline", "group__file.html#ga98e3daaa21c581e39c7822f1fccbb0ed", null ],
    [ "dvb_write_format_vdr", "group__file.html#gaa460d156c135d48ad66852e96b160fad", null ],
    [ "channel_file_format", "group__file.html#gaf409cf87507fb7021771af86f585498d", null ],
    [ "channel_file_zap_format", "group__file.html#ga7f350b370789fe6a5c52c4545f0526f7", null ]
];