var structdvb__table__sdt =
[
    [ "header", "structdvb__table__sdt.html#aa030adab955afc12a831f1fa0200d62c", null ],
    [ "network_id", "structdvb__table__sdt.html#acc3d4fa5003ae7c16be44eae1ef0a73c", null ],
    [ "reserved", "structdvb__table__sdt.html#a480757aaeb2d81c71c2ae6dab9bdba25", null ],
    [ "service", "structdvb__table__sdt.html#a455589397f505d0dc9dd34d779023037", null ]
];