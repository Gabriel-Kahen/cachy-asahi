var structdvb__desc__terrestrial__delivery =
[
    [ "bandwidth", "structdvb__desc__terrestrial__delivery.html#ad4d8373e8598dec52c1480addaa16bf0", null ],
    [ "centre_frequency", "structdvb__desc__terrestrial__delivery.html#ab45baf59be8662a9f1764edf72906b85", null ],
    [ "code_rate_hp_stream", "structdvb__desc__terrestrial__delivery.html#acbf790b7fe80e8d7b2b2113b75dc92d9", null ],
    [ "code_rate_lp_stream", "structdvb__desc__terrestrial__delivery.html#a94ae3591bfc6aebb0a3e27df3a2e926b", null ],
    [ "constellation", "structdvb__desc__terrestrial__delivery.html#a4e66dd8aefcf3e7f720f049ad2cef6cc", null ],
    [ "guard_interval", "structdvb__desc__terrestrial__delivery.html#a48b1cb5e25c63c413d4e5548ef7ed51b", null ],
    [ "hierarchy_information", "structdvb__desc__terrestrial__delivery.html#a3e683d8de83559f7fc10921caa319256", null ],
    [ "length", "structdvb__desc__terrestrial__delivery.html#a779ce9116ba3495a05c34088a469b071", null ],
    [ "mpe_fec_indicator", "structdvb__desc__terrestrial__delivery.html#ac7c3aaf2a9c1def221eb3988780caec9", null ],
    [ "next", "structdvb__desc__terrestrial__delivery.html#a6a0c6c49e28cf4f9ad57e57eec83c51b", null ],
    [ "other_frequency_flag", "structdvb__desc__terrestrial__delivery.html#aa3250c65d994cb38a0ef5768068c1e00", null ],
    [ "priority", "structdvb__desc__terrestrial__delivery.html#a64ddea76b433fa82b36198f249526103", null ],
    [ "reserved_future_use1", "structdvb__desc__terrestrial__delivery.html#a6a55ca6eee6451248069db873b56a18b", null ],
    [ "reserved_future_use2", "structdvb__desc__terrestrial__delivery.html#a0b6e3673a3304f8094e5f036e3f1034a", null ],
    [ "time_slice_indicator", "structdvb__desc__terrestrial__delivery.html#a16d872747400c0841b52645d42e65461", null ],
    [ "transmission_mode", "structdvb__desc__terrestrial__delivery.html#ab0eac8fdda11a5893f71f3db0d66e4be", null ],
    [ "type", "structdvb__desc__terrestrial__delivery.html#a3e6702f7870d0dadcc4b0f42537a34dd", null ]
];