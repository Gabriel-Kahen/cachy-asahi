var structdvb__desc__network__name =
[
    [ "length", "structdvb__desc__network__name.html#a883a221abada8591b5558d00ad27cdea", null ],
    [ "network_name", "structdvb__desc__network__name.html#a0ea46cb8a78b3687fd11e278f8bfc969", null ],
    [ "network_name_emph", "structdvb__desc__network__name.html#aab76bf73788d184bc64a2f55a623a316", null ],
    [ "next", "structdvb__desc__network__name.html#a6f25935b53c68db11dd05ee26151170e", null ],
    [ "type", "structdvb__desc__network__name.html#ae52b0eea685e9600c7cd960574e8ac7f", null ]
];