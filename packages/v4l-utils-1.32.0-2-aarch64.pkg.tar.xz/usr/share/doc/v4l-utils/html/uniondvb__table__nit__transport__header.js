var uniondvb__table__nit__transport__header =
[
    [ "bitfield", "uniondvb__table__nit__transport__header.html#aac404f8eb359bb5ee5812f022ea207b6", null ],
    [ "reserved", "uniondvb__table__nit__transport__header.html#ad8bde83263777c5ab2aa8882ec4f347e", null ],
    [ "transport_length", "uniondvb__table__nit__transport__header.html#a513e531719120ec10e29a086a259a6d8", null ]
];