var dvb_file_8h =
[
    [ "dvb_file", "structdvb__file.html", "structdvb__file" ],
    [ "dvb_parse_file", "structdvb__parse__file.html", "structdvb__parse__file" ],
    [ "dvb_file_formats", "group__file.html#ga189e923df3b573ee1881bcd2a1329e36", [
      [ "FILE_UNKNOWN", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a45cc741894b5757bae82fc08347264da", null ],
      [ "FILE_ZAP", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a364cd1d59248ff1e44e91dbd3a93f9c0", null ],
      [ "FILE_CHANNEL", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a232712daadb94d4736ee6c2e413f9b0d", null ],
      [ "FILE_DVBV5", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a6f92d4e99e0a29112a3d3d908fc85490", null ],
      [ "FILE_VDR", "dvb-file_8h.html#ga189e923df3b573ee1881bcd2a1329e36a9a682da8d7acc8581a8b3b3fc21bae1b", null ]
    ] ],
    [ "dvb_file_free", "group__file.html#ga5dfc7d72e44db45d235f267d7fb8bc70", null ],
    [ "dvb_parse_delsys", "group__file.html#gafd50356ff0c41ccdeb560c7c447f2526", null ],
    [ "dvb_parse_format", "group__file.html#gacfdc20d393ac4b0db8e830190491b506", null ],
    [ "dvb_parse_format_oneline", "group__file.html#ga5f02dc00b22235e99c50a0ceaf90a644", null ],
    [ "dvb_read_file", "group__file.html#gaa67c7236b7899f8dae5ff9c5a48c5225", null ],
    [ "dvb_read_file_format", "group__file.html#ga22160bafdc84d98663baf1c90f3080bd", null ],
    [ "dvb_retrieve_entry_prop", "group__file.html#ga45a0eea4649d09766b0d77f35f08bb0e", null ],
    [ "dvb_store_channel", "group__file.html#ga96968d8eae65990dd259f150f2a12aa6", null ],
    [ "dvb_store_entry_prop", "group__file.html#ga68e600a22d550f7c0e4a1c7d1c2f79cc", null ],
    [ "dvb_write_file", "group__file.html#gaec6ac24d9aaf7274b1a99ff9f5760ee2", null ],
    [ "dvb_write_file_format", "group__file.html#ga4e806ba940ac5498d9e2d04b0659b855", null ],
    [ "dvb_write_format_oneline", "group__file.html#ga98e3daaa21c581e39c7822f1fccbb0ed", null ],
    [ "dvb_write_format_vdr", "group__file.html#gaa460d156c135d48ad66852e96b160fad", null ],
    [ "channel_file_format", "group__file.html#gaf409cf87507fb7021771af86f585498d", null ],
    [ "channel_file_zap_format", "group__file.html#ga7f350b370789fe6a5c52c4545f0526f7", null ]
];