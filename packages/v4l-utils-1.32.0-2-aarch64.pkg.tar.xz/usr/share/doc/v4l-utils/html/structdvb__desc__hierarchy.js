var structdvb__desc__hierarchy =
[
    [ "channel", "structdvb__desc__hierarchy.html#a95c9fc438071421dee96551abb735522", null ],
    [ "embedded_layer", "structdvb__desc__hierarchy.html#a31e4f2811ba09f1fb615ff0567ad3c74", null ],
    [ "hierarchy_type", "structdvb__desc__hierarchy.html#ae76f99340037ff8c41db8d41761fa470", null ],
    [ "layer", "structdvb__desc__hierarchy.html#a18829259773795ed08fef9cf78e49e52", null ],
    [ "length", "structdvb__desc__hierarchy.html#ad61418514a3190d51f5895923c61b1b7", null ],
    [ "next", "structdvb__desc__hierarchy.html#a3619208b6d939d9bb39db334d01f28a6", null ],
    [ "reserved", "structdvb__desc__hierarchy.html#afcdb56c0544b7582677fc52cffcb3e3c", null ],
    [ "reserved2", "structdvb__desc__hierarchy.html#a1d2051cc7570d66347023ccbee7931e1", null ],
    [ "reserved3", "structdvb__desc__hierarchy.html#a006b73fa1f5d79e77c2b29bad48d71b2", null ],
    [ "reserved4", "structdvb__desc__hierarchy.html#a692dbc1323c694aaf45183361bc7ab1d", null ],
    [ "type", "structdvb__desc__hierarchy.html#acb4ba9dafee1869986c4ef1718695f3a", null ]
];