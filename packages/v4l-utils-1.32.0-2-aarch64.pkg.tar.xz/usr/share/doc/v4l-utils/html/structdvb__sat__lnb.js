var structdvb__sat__lnb =
[
    [ "dvbsat_freqrange", "structdvb__sat__lnb_1_1dvbsat__freqrange.html", "structdvb__sat__lnb_1_1dvbsat__freqrange" ],
    [ "alias", "structdvb__sat__lnb.html#a8f8460c251fa24ababfd1550a06defd0", null ],
    [ "freqrange", "structdvb__sat__lnb.html#aa804246a415be0c4fde0d507944071f7", null ],
    [ "highfreq", "structdvb__sat__lnb.html#a6388c2473a9f2275290edb00b5d103cc", null ],
    [ "lowfreq", "structdvb__sat__lnb.html#a7f9f2f32bb5551b72b9ce635517f2745", null ],
    [ "name", "structdvb__sat__lnb.html#ae7ec2931261802b1daa49090c1a176cf", null ],
    [ "rangeswitch", "structdvb__sat__lnb.html#ae57523456fdcdd2da084c6ac9362fb57", null ]
];