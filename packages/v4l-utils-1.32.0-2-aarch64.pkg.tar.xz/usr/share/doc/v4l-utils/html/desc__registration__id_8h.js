var desc__registration__id_8h =
[
    [ "dvb_desc_registration_free", "group__descriptors.html#ga880dc3841253d3aa4d539d9481461bc3", null ],
    [ "dvb_desc_registration_init", "group__descriptors.html#ga5a902c832622f5eea689668a58524196", null ],
    [ "dvb_desc_registration_print", "group__descriptors.html#gadff5324894dfdf05df70a145a62df62d", null ]
];