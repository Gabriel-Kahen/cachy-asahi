var structatsc__table__eit =
[
    [ "event", "structatsc__table__eit.html#a64be1c66e0cda945c03e7e60c0177dea", null ],
    [ "events", "structatsc__table__eit.html#af5ff6525bf39d84027bae8163b6976f8", null ],
    [ "header", "structatsc__table__eit.html#aa7ac99336eda014fcc6f3f04fdcdb013", null ],
    [ "protocol_version", "structatsc__table__eit.html#a0ca4a90b5f1c5991aecd54231642f213", null ]
];