var structdvb__desc__logical__channel__number =
[
    [ "bitfield", "structdvb__desc__logical__channel__number.html#a3131eab1c734626df2cb18a0e8d1f21e", null ],
    [ "logical_channel_number", "structdvb__desc__logical__channel__number.html#a094a40bd745b233d61b34166f784a2e4", null ],
    [ "reserved", "structdvb__desc__logical__channel__number.html#aa149904719d79647d74405d9619b8944", null ],
    [ "service_id", "structdvb__desc__logical__channel__number.html#a5010242b35d52a1f3588640e83b3a675", null ],
    [ "visible_service_flag", "structdvb__desc__logical__channel__number.html#aa64beb9e3df9da67ddc6e86ea3923f55", null ]
];