var structatsc__table__mgt =
[
    [ "descriptor", "structatsc__table__mgt.html#a318f9132e6f2e254de9952f46b10c9ac", null ],
    [ "header", "structatsc__table__mgt.html#ae4d3aa2c0824e8d9bdab89b98e62971e", null ],
    [ "protocol_version", "structatsc__table__mgt.html#a3e666d0ef64ae791dd58040ba1e96ee9", null ],
    [ "table", "structatsc__table__mgt.html#a3a872935d9d975adabe93775aef7d727", null ],
    [ "tables", "structatsc__table__mgt.html#a6c87e3840c47ca7ea3753d02aeb89976", null ]
];