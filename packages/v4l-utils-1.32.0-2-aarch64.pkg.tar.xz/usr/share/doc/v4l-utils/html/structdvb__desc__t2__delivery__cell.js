var structdvb__desc__t2__delivery__cell =
[
    [ "cell_id", "structdvb__desc__t2__delivery__cell.html#a0d0c6cad1b9884382a3787a9834c85e7", null ],
    [ "centre_frequency", "structdvb__desc__t2__delivery__cell.html#a672a9a39a8d18fce84ac650fe2b0251e", null ],
    [ "num_freqs", "structdvb__desc__t2__delivery__cell.html#a465f66aec2d792bdcac4d27b010d7e97", null ],
    [ "subcel", "structdvb__desc__t2__delivery__cell.html#a9843e720978ca25992908c588942035a", null ],
    [ "subcel_length", "structdvb__desc__t2__delivery__cell.html#ac457625e533184819dd2cf4f3556ee5e", null ]
];