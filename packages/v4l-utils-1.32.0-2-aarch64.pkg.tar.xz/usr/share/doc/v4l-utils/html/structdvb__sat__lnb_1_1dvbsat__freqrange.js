var structdvb__sat__lnb_1_1dvbsat__freqrange =
[
    [ "high", "structdvb__sat__lnb_1_1dvbsat__freqrange.html#ab0fb6859975e04bae3f2efe440637dcb", null ],
    [ "low", "structdvb__sat__lnb_1_1dvbsat__freqrange.html#ac1f35244ceb84b5b42f676ff0e528578", null ]
];