var structdvb__desc__logical__channel =
[
    [ "lcn", "structdvb__desc__logical__channel.html#a2b865b8692de6f0cf22d553dead1e9eb", null ],
    [ "length", "structdvb__desc__logical__channel.html#a3845654112ea677bbefdfa3d2a36f81f", null ],
    [ "next", "structdvb__desc__logical__channel.html#a765898e72916aa66c335c4ae1c3b6abd", null ],
    [ "type", "structdvb__desc__logical__channel.html#a2f0a2d4b39a89646924867ee2629d00d", null ]
];