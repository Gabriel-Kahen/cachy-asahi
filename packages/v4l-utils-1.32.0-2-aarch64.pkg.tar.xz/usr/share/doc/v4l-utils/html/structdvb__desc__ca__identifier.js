var structdvb__desc__ca__identifier =
[
    [ "caid_count", "structdvb__desc__ca__identifier.html#a5415962dc990d07d078d4da78863f6a3", null ],
    [ "caids", "structdvb__desc__ca__identifier.html#abb5b47b33258ecefc5df7fdfd8f940b7", null ],
    [ "length", "structdvb__desc__ca__identifier.html#a7f1c75183c31af04a394363097dfcf67", null ],
    [ "next", "structdvb__desc__ca__identifier.html#a4412bd6cf2ee44dbd8b82ae4feb61c1f", null ],
    [ "type", "structdvb__desc__ca__identifier.html#a65290f3eb25ec830c93d05a9468d9273", null ]
];