var desc__event__short_8h =
[
    [ "dvb_desc_event_short_free", "group__descriptors.html#gaa66983227a66d422b43ea3c7e53ab3b2", null ],
    [ "dvb_desc_event_short_init", "group__descriptors.html#gad71426829b0a8f1b1de4d06154297739", null ],
    [ "dvb_desc_event_short_print", "group__descriptors.html#ga8e1cbee8b6c1fcf7fcaef8c39e5de67c", null ]
];