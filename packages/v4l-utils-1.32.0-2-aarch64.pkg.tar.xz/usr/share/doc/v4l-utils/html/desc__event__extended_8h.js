var desc__event__extended_8h =
[
    [ "dvb_desc_event_extended_item", "structdvb__desc__event__extended__item.html", "structdvb__desc__event__extended__item" ],
    [ "dvb_desc_event_extended_free", "group__descriptors.html#ga731f16559d2678e8735636d756711fe1", null ],
    [ "dvb_desc_event_extended_init", "group__descriptors.html#ga9f0261f4db926384adec421c49600fdb", null ],
    [ "dvb_desc_event_extended_print", "group__descriptors.html#ga18d7a86a49b9ff13e7439068bb268de1", null ]
];