var dvb_dev_8h =
[
    [ "dvb_dev_change_t", "dvb-dev_8h.html#ae49ed13bc30087cabbaaa93e73a96a44", null ],
    [ "dvb_dev_change_type", "dvb-dev_8h.html#aa62bddea4ab808e81b3a8fae609b82f3", [
      [ "DVB_DEV_ADD", "dvb-dev_8h.html#aa62bddea4ab808e81b3a8fae609b82f3ab745257c4a704f4f259dc589f9ad8e15", null ],
      [ "DVB_DEV_CHANGE", "dvb-dev_8h.html#aa62bddea4ab808e81b3a8fae609b82f3ad89e58ebc21ef23b1fe940aeaae4f88b", null ],
      [ "DVB_DEV_REMOVE", "dvb-dev_8h.html#aa62bddea4ab808e81b3a8fae609b82f3a9f1b3f3e34a9ab3526931b6dd0099d9c", null ]
    ] ],
    [ "dvb_dev_type", "group__dvb__device.html#gafd674cd2bc121b8e869620df5af4818c", [
      [ "DVB_DEVICE_FRONTEND", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cabe57f9b6faa76558dd4b558c68b1b6e9", null ],
      [ "DVB_DEVICE_DEMUX", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818caa00d24d2a563c244710aa80ce79227e0", null ],
      [ "DVB_DEVICE_DVR", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cace851296cdcbb04306b51543f3ebe989", null ],
      [ "DVB_DEVICE_NET", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca47745289262fc5b26d1751d52b7d810a", null ],
      [ "DVB_DEVICE_CA", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cad944d8d760919200371952efbfb3a615", null ],
      [ "DVB_DEVICE_CA_SEC", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca887e3bc8ad7d9eac46da1beb62fff94b", null ],
      [ "DVB_DEVICE_VIDEO", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cafacb4aacfe2c7e07536105acee27d818", null ],
      [ "DVB_DEVICE_AUDIO", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca40fa43e0c848c74e6315c7e0cc3f716f", null ]
    ] ],
    [ "dvb_dev_alloc", "group__dvb__device.html#gadfd13128c35d94398cba9f1ba2b9c753", null ],
    [ "dvb_dev_close", "group__dvb__device.html#gae47352af27ffd35b8d21401334d101e3", null ],
    [ "dvb_dev_dmx_get_pmt_pid", "group__dvb__device.html#ga40eb6e942a2937e3a5a5dc34e2d37b4c", null ],
    [ "dvb_dev_dmx_set_pesfilter", "group__dvb__device.html#ga48cbb0ee596f8429b342fa44169e24d1", null ],
    [ "dvb_dev_dmx_set_section_filter", "group__dvb__device.html#ga7317383b1e4ff62287d3a7431ab905c3", null ],
    [ "dvb_dev_dmx_stop", "group__dvb__device.html#ga55fd8c2876eae9d70fcf3be16183cb37", null ],
    [ "dvb_dev_find", "group__dvb__device.html#ga83b6ade889c4fa347bea1b2ac2c276e0", null ],
    [ "dvb_dev_free", "group__dvb__device.html#ga1a807ca7d90139b409ed9b442e7fac8b", null ],
    [ "dvb_dev_get_fd", "group__dvb__device.html#gab7c74324f2d5b29dae731caf7f16f74a", null ],
    [ "dvb_dev_open", "group__dvb__device.html#ga2485623c5e27347336e5ea04b880f2f6", null ],
    [ "dvb_dev_read", "group__dvb__device.html#gad7886c51c6e2194bd22bd59bde0e9d82", null ],
    [ "dvb_dev_remote_init", "dvb-dev_8h.html#a443d808b32ca01ae3c7a1d6b960616e4", null ],
    [ "dvb_dev_scan", "group__frontend__scan.html#ga7d1a36c639c7d73d6b13d2d5badbc4a8", null ],
    [ "dvb_dev_seek_by_adapter", "dvb-dev_8h.html#abe503aae6ecb403d9f4ea351d0c2186a", null ],
    [ "dvb_dev_set_bufsize", "group__dvb__device.html#ga9e8de268a6a81ce2d3e58ab5fcef0819", null ],
    [ "dvb_dev_set_log", "group__dvb__device.html#gabcb9d3794a3be4be5c212c0cc6ac9b06", null ],
    [ "dvb_dev_set_logpriv", "group__dvb__device.html#gaefbc41189a25a5c5e73f0ba141c8dda0", null ],
    [ "dvb_dev_stop_monitor", "group__dvb__device.html#ga2942e832cff04efa97bc769c1bb87f9a", null ],
    [ "dvb_get_dev_info", "dvb-dev_8h.html#a82c71bb01c257f3583ac66f796319029", null ]
];