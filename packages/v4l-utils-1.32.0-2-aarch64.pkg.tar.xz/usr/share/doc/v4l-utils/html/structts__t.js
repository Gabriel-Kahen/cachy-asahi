var structts__t =
[
    [ "bitfield", "structts__t.html#acf976003c9ecee3fad30f5574d10e8cb", null ],
    [ "bitfield2", "structts__t.html#acc663a5e4c587ed5c0fafe02eb8ba5d9", null ],
    [ "bits00", "structts__t.html#ad57ded185a321d80f93454e35c22c7f7", null ],
    [ "bits15", "structts__t.html#a647abc15301881a4f071ed6c60967144", null ],
    [ "bits30", "structts__t.html#a8f6d020bd7d5edd6b15dbb906b96a902", null ],
    [ "one", "structts__t.html#a15f02164a4f8e0f81d1e129da7ce00bf", null ],
    [ "one1", "structts__t.html#a69f06223b256584c951e5bd7298e5979", null ],
    [ "one2", "structts__t.html#af5e0ab656441aa88125d6b78147f680e", null ],
    [ "tag", "structts__t.html#ac2684ec7eb36deac1b0e096b53a08552", null ]
];