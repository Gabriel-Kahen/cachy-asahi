var structdvb__desc__t2__delivery__subcell =
[
    [ "cell_id_extension", "structdvb__desc__t2__delivery__subcell.html#a9374f6eab471801f72acfa772dd2b83f", null ],
    [ "transposer_frequency", "structdvb__desc__t2__delivery__subcell.html#a0e80fb282e3350940fbe16ddcb73ac14", null ]
];