var structatsc__table__mgt__table =
[
    [ "bitfield", "structatsc__table__mgt__table.html#a037e98d071b287c3c390ffa98ab53c1c", null ],
    [ "bitfield2", "structatsc__table__mgt__table.html#ac1391c4dd7dce7b76c1557e19bc26c5e", null ],
    [ "desc_length", "structatsc__table__mgt__table.html#ab0d1ecd3d828ee5feba58586d4d122b6", null ],
    [ "descriptor", "structatsc__table__mgt__table.html#a1d1d325a69040ccd9c23899cdf767496", null ],
    [ "next", "structatsc__table__mgt__table.html#a3c19b52ebf5cfb2df242fdc8800d6786", null ],
    [ "one", "structatsc__table__mgt__table.html#ab224c852d242ad089c37cfb59c0b515a", null ],
    [ "one2", "structatsc__table__mgt__table.html#a62369b1449341da4158bf43b0db2b5e3", null ],
    [ "one3", "structatsc__table__mgt__table.html#abbf39139e51ac4551bf95b7381d4d418", null ],
    [ "pid", "structatsc__table__mgt__table.html#ae0583e6cbf19e0830b5910067520e8cc", null ],
    [ "size", "structatsc__table__mgt__table.html#a420778d96e24bbd196713bd7a177634a", null ],
    [ "type", "structatsc__table__mgt__table.html#a87480451fc847c5bf778ee1d035e1efe", null ],
    [ "type_version", "structatsc__table__mgt__table.html#a996308792d71dc86045117e481868aa9", null ]
];