var structdvb__parse__file =
[
    [ "delimiter", "structdvb__parse__file.html#a5c0bb11aab0fa8387ca107a1f33b9ca4", null ],
    [ "formats", "structdvb__parse__file.html#ad4125d72caa2d1217d36d410785ffb24", null ],
    [ "has_delsys_id", "structdvb__parse__file.html#afc5337d0fa3dcf6c8b5da28a73c1789f", null ]
];