var unionatsc__table__vct__descriptor__length =
[
    [ "bitfield", "unionatsc__table__vct__descriptor__length.html#a43e3a0c60a7d3f57a2213bc498d28469", null ],
    [ "descriptor_length", "unionatsc__table__vct__descriptor__length.html#a3aa02bc87b281a66fd78149eed98f1eb", null ],
    [ "reserved", "unionatsc__table__vct__descriptor__length.html#a8c54193297aa2480022e2d12f0dd727b", null ]
];