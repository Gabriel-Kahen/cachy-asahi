var desc__frequency__list_8h =
[
    [ "dvb_desc_frequency_list_init", "group__descriptors.html#gab21ab6c8e61dae6f55cdf86fb2b98e5f", null ],
    [ "dvb_desc_frequency_list_print", "group__descriptors.html#ga3cef6d987aa6d936460cbfa0d303fdb0", null ]
];