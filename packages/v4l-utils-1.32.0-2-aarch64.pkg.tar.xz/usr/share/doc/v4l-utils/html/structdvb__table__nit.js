var structdvb__table__nit =
[
    [ "bitfield", "structdvb__table__nit.html#a5abd9a65b33fed2a4616f61d234a88ee", null ],
    [ "desc_length", "structdvb__table__nit.html#a33c3cce1345716f81fff473a0bdf0fa9", null ],
    [ "descriptor", "structdvb__table__nit.html#a2eecaaf5a211227217f628aec2e92749", null ],
    [ "header", "structdvb__table__nit.html#aeb072279e948301c08ef08833da6d0dd", null ],
    [ "reserved", "structdvb__table__nit.html#a80d2f3752f36721bd3d9abd6d56e7f92", null ],
    [ "transport", "structdvb__table__nit.html#a36ff7c5aa024054364c7f754819d576f", null ]
];