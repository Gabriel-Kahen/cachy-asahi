var structisdbt__desc__terrestrial__delivery__system =
[
    [ "area_code", "structisdbt__desc__terrestrial__delivery__system.html#a83938af7f0462fe569c7e76b06670090", null ],
    [ "bitfield", "structisdbt__desc__terrestrial__delivery__system.html#a3a332e024c75d458734845873a61a3a7", null ],
    [ "frequency", "structisdbt__desc__terrestrial__delivery__system.html#a33b91e269c286f1b15fffe7e899989c1", null ],
    [ "guard_interval", "structisdbt__desc__terrestrial__delivery__system.html#a1221afad3e04063d166450fe4d274859", null ],
    [ "length", "structisdbt__desc__terrestrial__delivery__system.html#aeac4b6c9e1f3eba8550843cd25fe6035", null ],
    [ "next", "structisdbt__desc__terrestrial__delivery__system.html#abc747cad1391c6e836ffe5bfbfa89299", null ],
    [ "num_freqs", "structisdbt__desc__terrestrial__delivery__system.html#abfec29eadb0f215f77228da5d2c0f217", null ],
    [ "transmission_mode", "structisdbt__desc__terrestrial__delivery__system.html#ac0789991b4578ef72c0627f6695dad00", null ],
    [ "type", "structisdbt__desc__terrestrial__delivery__system.html#a186c10284fd549c9fa93afaa6412ba55", null ]
];