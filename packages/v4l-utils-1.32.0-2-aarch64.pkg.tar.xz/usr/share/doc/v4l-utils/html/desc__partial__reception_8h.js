var desc__partial__reception_8h =
[
    [ "isdb_desc_partial_reception_free", "group__descriptors.html#gaa413ffdaad376818f46922db2cc7aba6", null ],
    [ "isdb_desc_partial_reception_init", "group__descriptors.html#ga64d79c6fb0290232c7644c540baf51b9", null ],
    [ "isdb_desc_partial_reception_print", "group__descriptors.html#gade561a5fc616aee1e1fbba93f7a2abf3", null ]
];