var group__satellite =
[
    [ "dvb-sat.h", "dvb-sat_8h.html", null ],
    [ "dvb_sat_lnb", "structdvb__sat__lnb.html", [
      [ "dvbsat_freqrange", "structdvb__sat__lnb_1_1dvbsat__freqrange.html", [
        [ "high", "structdvb__sat__lnb_1_1dvbsat__freqrange.html#ab0fb6859975e04bae3f2efe440637dcb", null ],
        [ "low", "structdvb__sat__lnb_1_1dvbsat__freqrange.html#ac1f35244ceb84b5b42f676ff0e528578", null ]
      ] ],
      [ "alias", "structdvb__sat__lnb.html#a8f8460c251fa24ababfd1550a06defd0", null ],
      [ "freqrange", "structdvb__sat__lnb.html#aa804246a415be0c4fde0d507944071f7", null ],
      [ "highfreq", "structdvb__sat__lnb.html#a6388c2473a9f2275290edb00b5d103cc", null ],
      [ "lowfreq", "structdvb__sat__lnb.html#a7f9f2f32bb5551b72b9ce635517f2745", null ],
      [ "name", "structdvb__sat__lnb.html#ae7ec2931261802b1daa49090c1a176cf", null ],
      [ "rangeswitch", "structdvb__sat__lnb.html#ae57523456fdcdd2da084c6ac9362fb57", null ]
    ] ],
    [ "dvb_sat_polarization", "group__satellite.html#ga6010ef4a66faa5ca7d3baf0075c019e7", [
      [ "POLARIZATION_OFF", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7ad483ddd6e893d8e069f3bb98fb2ab775", null ],
      [ "POLARIZATION_H", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7acd596b91e205ca9bb9cd32d4f6937f7e", null ],
      [ "POLARIZATION_V", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7a4d2bd2c3be3d6ccf68db5cc8d803fb08", null ],
      [ "POLARIZATION_L", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7ae5a87f0b3c42c6fe16b44bce403a904a", null ],
      [ "POLARIZATION_R", "dvb-v5-std_8h.html#ga6010ef4a66faa5ca7d3baf0075c019e7a2cbc3a93ac7b093d489649efd38e3d6e", null ]
    ] ],
    [ "dvb_print_all_lnb", "group__satellite.html#ga331da0c0d4a550eb197a9cde59130c1e", null ],
    [ "dvb_print_lnb", "group__satellite.html#ga7662df9e20b4d2e1c8f1bebb3b347fd7", null ],
    [ "dvb_sat_get_lnb", "group__satellite.html#gaaa68df35cf1bd980ad8b96d9867d65b7", null ],
    [ "dvb_sat_get_lnb_name", "group__satellite.html#gad39f91119ebf9cc234b569c8e51425bc", null ],
    [ "dvb_sat_real_freq", "group__satellite.html#gad932fc845fcbd4ab1ecdd230267a1b1f", null ],
    [ "dvb_sat_search_lnb", "group__satellite.html#gac9cde4ada62dd033cdbc189835c620c7", null ],
    [ "dvb_sat_set_parms", "group__satellite.html#gad5db6978b0b5886968a372f7334c5236", null ]
];