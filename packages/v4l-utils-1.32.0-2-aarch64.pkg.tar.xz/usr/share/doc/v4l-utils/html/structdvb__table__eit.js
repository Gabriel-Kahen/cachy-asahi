var structdvb__table__eit =
[
    [ "event", "structdvb__table__eit.html#ad5d7ba46a828b43d5ade4f6c901abe4b", null ],
    [ "header", "structdvb__table__eit.html#a666247c2863e8cf1572ec62b89661689", null ],
    [ "last_segment", "structdvb__table__eit.html#ac0dff91cd1ecac2bf298067f61b39859", null ],
    [ "last_table_id", "structdvb__table__eit.html#a0cc9df4dcf7d4fcb7a7b090f2a9d8d57", null ],
    [ "network_id", "structdvb__table__eit.html#ab86d33e1e2d43133d819aef153519ac4", null ],
    [ "transport_id", "structdvb__table__eit.html#a496a61b93ef3c20cf45e470cf65340f0", null ]
];