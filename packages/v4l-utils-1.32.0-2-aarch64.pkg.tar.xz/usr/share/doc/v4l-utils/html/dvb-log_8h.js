var dvb_log_8h =
[
    [ "dvb_logfunc", "group__ancillary.html#ga76e4a406268472f67a12abf2243e09f4", null ],
    [ "dvb_logfunc_priv", "dvb-log_8h.html#a244fafcfc393951fe9e33bd229cd131f", null ],
    [ "dvb_default_log", "group__ancillary.html#ga89d0c0b1e0c9daa91c8dbda4b3f235ae", null ]
];