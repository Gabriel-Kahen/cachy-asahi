var group__dvb__device =
[
    [ "dvb-dev.h", "dvb-dev_8h.html", null ],
    [ "dvb_dev_list", "structdvb__dev__list.html", [
      [ "bus_addr", "structdvb__dev__list.html#a15413bc2c628b2800f403a857e19495f", null ],
      [ "bus_id", "structdvb__dev__list.html#a61f21a0ebeec23821258051864abf892", null ],
      [ "dvb_type", "structdvb__dev__list.html#a20a9c7d7de8b7d35fe70a6a33725d503", null ],
      [ "manufacturer", "structdvb__dev__list.html#ad96647c75f85e795704708c8acc8c613", null ],
      [ "path", "structdvb__dev__list.html#ad1780dde3dd0ef85d7cc3b80967cf740", null ],
      [ "product", "structdvb__dev__list.html#a733a45940f2936862ce8b0531e850ffd", null ],
      [ "serial", "structdvb__dev__list.html#a4b1cbe0b796488f42e117aeebdfe0ee4", null ],
      [ "sysname", "structdvb__dev__list.html#ab8dddb061b9f9b2f3c758802880b538f", null ],
      [ "syspath", "structdvb__dev__list.html#a2930d26c660a0515eda6fb28b55ad88d", null ]
    ] ],
    [ "dvb_device", "structdvb__device.html", [
      [ "devices", "structdvb__device.html#abeb384f9fb1fb3a8b61d542f05432123", null ],
      [ "fe_parms", "structdvb__device.html#a7bdecdc55857d11baa6b76200737e695", null ],
      [ "num_devices", "structdvb__device.html#a95db66d7401506276e7ad5369d6b4087", null ]
    ] ],
    [ "dvb_dev_type", "group__dvb__device.html#gafd674cd2bc121b8e869620df5af4818c", [
      [ "DVB_DEVICE_FRONTEND", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cabe57f9b6faa76558dd4b558c68b1b6e9", null ],
      [ "DVB_DEVICE_DEMUX", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818caa00d24d2a563c244710aa80ce79227e0", null ],
      [ "DVB_DEVICE_DVR", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cace851296cdcbb04306b51543f3ebe989", null ],
      [ "DVB_DEVICE_NET", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca47745289262fc5b26d1751d52b7d810a", null ],
      [ "DVB_DEVICE_CA", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cad944d8d760919200371952efbfb3a615", null ],
      [ "DVB_DEVICE_CA_SEC", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca887e3bc8ad7d9eac46da1beb62fff94b", null ],
      [ "DVB_DEVICE_VIDEO", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818cafacb4aacfe2c7e07536105acee27d818", null ],
      [ "DVB_DEVICE_AUDIO", "dvb-dev_8h.html#gafd674cd2bc121b8e869620df5af4818ca40fa43e0c848c74e6315c7e0cc3f716f", null ]
    ] ],
    [ "dvb_dev_alloc", "group__dvb__device.html#gadfd13128c35d94398cba9f1ba2b9c753", null ],
    [ "dvb_dev_close", "group__dvb__device.html#gae47352af27ffd35b8d21401334d101e3", null ],
    [ "dvb_dev_dmx_get_pmt_pid", "group__dvb__device.html#ga40eb6e942a2937e3a5a5dc34e2d37b4c", null ],
    [ "dvb_dev_dmx_set_pesfilter", "group__dvb__device.html#ga48cbb0ee596f8429b342fa44169e24d1", null ],
    [ "dvb_dev_dmx_set_section_filter", "group__dvb__device.html#ga7317383b1e4ff62287d3a7431ab905c3", null ],
    [ "dvb_dev_dmx_stop", "group__dvb__device.html#ga55fd8c2876eae9d70fcf3be16183cb37", null ],
    [ "dvb_dev_find", "group__dvb__device.html#ga83b6ade889c4fa347bea1b2ac2c276e0", null ],
    [ "dvb_dev_free", "group__dvb__device.html#ga1a807ca7d90139b409ed9b442e7fac8b", null ],
    [ "dvb_dev_get_fd", "group__dvb__device.html#gab7c74324f2d5b29dae731caf7f16f74a", null ],
    [ "dvb_dev_open", "group__dvb__device.html#ga2485623c5e27347336e5ea04b880f2f6", null ],
    [ "dvb_dev_read", "group__dvb__device.html#gad7886c51c6e2194bd22bd59bde0e9d82", null ],
    [ "dvb_dev_set_bufsize", "group__dvb__device.html#ga9e8de268a6a81ce2d3e58ab5fcef0819", null ],
    [ "dvb_dev_set_log", "group__dvb__device.html#gabcb9d3794a3be4be5c212c0cc6ac9b06", null ],
    [ "dvb_dev_set_logpriv", "group__dvb__device.html#gaefbc41189a25a5c5e73f0ba141c8dda0", null ],
    [ "dvb_dev_stop_monitor", "group__dvb__device.html#ga2942e832cff04efa97bc769c1bb87f9a", null ]
];