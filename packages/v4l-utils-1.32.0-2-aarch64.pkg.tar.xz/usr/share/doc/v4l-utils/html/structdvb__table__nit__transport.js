var structdvb__table__nit__transport =
[
    [ "bitfield", "structdvb__table__nit__transport.html#a9c01476c8018d1287c4c0f18e0b0b49d", null ],
    [ "desc_length", "structdvb__table__nit__transport.html#a8713036db7e97a2cd45a9667e43342c3", null ],
    [ "descriptor", "structdvb__table__nit__transport.html#a734ef94ad711af64442456eea218ea04", null ],
    [ "network_id", "structdvb__table__nit__transport.html#a0d184861a2e30cdde03d3da9f160cd63", null ],
    [ "next", "structdvb__table__nit__transport.html#aeffed9b42647366002cadf29b545c46e", null ],
    [ "reserved", "structdvb__table__nit__transport.html#a5c31e5447419c6102d461d741bfa4d61", null ],
    [ "transport_id", "structdvb__table__nit__transport.html#a8f002dd7335c0e18ec5e3c903d5cd073", null ]
];