var structdvb__entry =
[
    [ "audio_pid", "structdvb__entry.html#a43222f11e4a5788718a2e2e789c546f1", null ],
    [ "audio_pid_len", "structdvb__entry.html#a139e5b83d0100cdbbc9e66b2419b2878", null ],
    [ "channel", "structdvb__entry.html#a95383462df05b5055212999cfb9af2fc", null ],
    [ "diseqc_wait", "structdvb__entry.html#a452a8ca6d2a09383c369a1374467d543", null ],
    [ "freq_bpf", "structdvb__entry.html#ace8a3953d73917a7907297a89e92b73e", null ],
    [ "lnb", "structdvb__entry.html#a16545c27b357e3144c04a224e9e61278", null ],
    [ "location", "structdvb__entry.html#a269704d91ab79839bae28e5466133f17", null ],
    [ "n_props", "structdvb__entry.html#a37594dfcb911f719a590f012f732ed53", null ],
    [ "network_id", "structdvb__entry.html#a7f000408b55a5e5499ca2cbc95140b5c", null ],
    [ "next", "structdvb__entry.html#ab36ec69e316a685f2527cb2f2820cfe3", null ],
    [ "other_el_pid", "structdvb__entry.html#a39e89bf2b7045a0b2a38ce9da9857e03", null ],
    [ "other_el_pid_len", "structdvb__entry.html#a5daff6ffb17b970d2add0c1ac1d69870", null ],
    [ "props", "structdvb__entry.html#a38b8ff1806fed84a71b167f269a83bcf", null ],
    [ "sat_number", "structdvb__entry.html#ad2ead2bf639f720fa3589718e623b4b6", null ],
    [ "service_id", "structdvb__entry.html#aa8675380605ed6bdddb4d5ccce263a5b", null ],
    [ "transport_id", "structdvb__entry.html#a9ce250e50e2d8eb50358ffa744e9daf0", null ],
    [ "vchannel", "structdvb__entry.html#ae811cc0a7088eaaa18c5a834e6a51d2f", null ],
    [ "video_pid", "structdvb__entry.html#a3d47b2030b0d018e142915631362a030", null ],
    [ "video_pid_len", "structdvb__entry.html#a4e3d53068d94826d7214bbd0bb4317c9", null ]
];