var desc__logical__channel_8h =
[
    [ "dvb_desc_logical_channel_free", "group__descriptors.html#ga776e52ef217be76c85425e330339c2a7", null ],
    [ "dvb_desc_logical_channel_init", "group__descriptors.html#gaa3bbba66c5743691831422f2173d4446", null ],
    [ "dvb_desc_logical_channel_print", "group__descriptors.html#ga09657280b5d50928620e035a7e50e1fe", null ]
];