var structdvb__descriptor =
[
    [ "free", "structdvb__descriptor.html#ae8e20eb700358f25c95224c9b74f82d1", null ],
    [ "init", "structdvb__descriptor.html#a33dca44396198450a897be46480964cf", null ],
    [ "name", "structdvb__descriptor.html#a5338317ba97a0a5518dc4356a14afea1", null ],
    [ "print", "structdvb__descriptor.html#afd9801c17598348439518e57283ae0e5", null ],
    [ "size", "structdvb__descriptor.html#a71437458f010032e1790c3d1c31717b6", null ]
];