# Source availability: bankstown

The original tested build inputs are fixed at project Source
6983455c92ac39064909923836d7c5122d423f0f:
https://github.com/Gabriel-Kahen/cachy-asahi/tree/6983455c92ac39064909923836d7c5122d423f0f/packages/audio/bankstown

The exact shared vendor source archive is available at:
https://raw.githubusercontent.com/Gabriel-Kahen/cachy-asahi/6983455c92ac39064909923836d7c5122d423f0f/packages/audio/speakersafetyd/cargo-vendor-117.tar.xz
SHA256:64cd55473b19f104f3a90570409d58c5ab69f63c61396541c4ad1e56e8d6293f
Size:5,733,816bytes. It contains all117 crates, original license texts and
Cargo checksum manifests. Source terms remain those in the individual crates.
This input URL responded HTTP200 to a HEAD request on2026-10-15; source hashes
here are pinned to retained input bytes and immutable project revision.

These links identify actual original code/vendor inputs. They do not by
themselves supply a new notice-packaging revision or establish complete
corresponding-source delivery for any future package. That package's exact
recipe/notices/source index must be published with its binaries. This
proposal has not been installed or released.
