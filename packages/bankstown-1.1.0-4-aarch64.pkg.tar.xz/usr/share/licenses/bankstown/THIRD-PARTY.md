# Third-party components: bankstown

This proposed notice set identifies all17 registry crates in the tested
Cargo lock, including build/procedural-macro/target-specific entries. It does
not assert every entry is linked into the final output. Source declarations
are reproduced unchanged; supplemental texts are separately identified.
The original root license remains in LICENSE or LICENCE.txt.

The proposed distribution choices are **MIT for configparser3.2.0** and
**Zlib for wide0.7.32** wherever present. Other original alternatives are
preserved with their texts. Additive Unicode and file-level notices remain.
These records do not globally relabel third-party source.

wmidi's later upstream text and the nalgebra macro's workspace text, where
present, each have a SOURCE-ATTRIBUTION.md section in THIRD-PARTY-LICENSES.txt explaining their exact provenance
and remaining association limits. No missing copyright holder was invented.

| Crate/version | Unchanged upstream expression | Proposed selection / record |
| --- | --- | --- |
| biquad@0.4.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| libm@0.1.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-atom@2.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-core-derive@2.1.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-core@3.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-midi@1.2.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-sys@2.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-units@0.1.3 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-urid@2.1.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2@0.6.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| proc-macro2@1.0.69 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| quote@1.0.33 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| syn@1.0.109 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| unicode-ident@1.0.12 | `(MIT OR Apache-2.0) AND Unicode-DFS-2016` | Original alternatives/terms retained; no additional choice recorded |
| urid-derive@0.1.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| urid@0.1.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| wmidi@3.1.0 | `MIT` | MIT |
