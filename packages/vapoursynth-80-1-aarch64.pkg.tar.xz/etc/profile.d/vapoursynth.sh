export VSSCRIPT_PATH='/usr/lib/python3.14/site-packages/vapoursynth/libvsscript.so'
