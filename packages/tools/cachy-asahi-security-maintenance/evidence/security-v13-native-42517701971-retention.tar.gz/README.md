# Security v13 finite native component retention

Local prepublication snapshot; archive publication is NOT_RUN here. Root qualified only the finite native signed-upgrade and exact interrupted-recovery component evidence for Source888/run42517701971. Normal precommit decline is separate from controlled original-pidfd SIGKILL at the first genuine UPGRADE-zero credentialed frozen checkpoint. Arbitrary signal timing and power loss remain NOT_QUALIFIED.

The original artifact.zip is retained byte-for-byte. Source raw commit/full209 map and identity, matching14 closure, public strict-reader facts and Root decision/body facts complete the allowlist. Reader Root_native_acceptance remains null; Root's separate decision qualifies finite component evidence only. Native16K, physical M2, performance, remediation, release and upstream source/binary correspondence remain unqualified/open as recorded.

This static retention does not fetch, decode or extract the original capsule, call Reader or execute Source/native actors. Local custody, HTTP/auth/header records, signed redirect URLs, credentials and whole private packet directories are excluded. Public JSON records are explicit projections; their original local receipt pins are evidence references, not signatures.
