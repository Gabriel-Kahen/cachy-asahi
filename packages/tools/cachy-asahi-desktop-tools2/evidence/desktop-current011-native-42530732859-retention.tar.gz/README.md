# DesktopTools current011 finite native component evidence

Prepared public retention candidate for Source a788d58531de9315b28450a61b20ea1737a127e1, run 42530732859, attempt1, job 128884127256, artifact 13637053944. Root qualified only the finite generic native ARM DesktopTools ALPM component.

artifact.zip is the unchanged whole original883809-byte GitHub ZIP, SHA256 e1fd02db46f7c6b0aed012aef765fecd5c03bc991dc73e09104e571931f64523. Its sole public-tree.tar is not duplicated. Existing public TEST-signature/key metadata grants no production signing authority.

The strict matching f64a61 reader ran once, with actor denial, returning VALIDATED_NATIVE_DESKTOP_TOOLS_ALPM_COMPONENT_EVIDENCE_ONLY. Two distinct clean0.1.1-1 native ARM builds each passed91 actual makepkg checks and matched package archive/payload/PKGINFO/BUILDINFO/MTREE bytes. Signed install, static CLI audits from /usr and a moved root, environment lifecycle, TEST-only0.1.1-2 pkgrel fixture update with unchanged payload, removal, exact349/350/350/349 inventories, protected-state restoration and owned retirement qualified. This is not a production update test or GUI capture/application-launch test.

Native16K remains NOT_QUALIFIED; physicalM2/Asahi and GUI capture/application launch NOT_RUN; performance NOT_MEASURED; production trust and release NOT_ADMITTED. Reader flags remain unchanged, including native NOT_ADMITTED, Root_acceptance null and positive_component_acceptance false. Root's separate decision qualifies only the bounded component.

The full Source200 blob/body/mode map, exact advertised map199, raw commit, trusted14-file/10-module reader pins and public fact projections accompany the original ZIP. Public reader binding omits its ephemeral token; original49106-byte strict receipt and every original flag remain unchanged locally. Private custody paths, lease records, HTTP/auth headers, redirects and credentials are excluded. No artifact code is executed. Only this allowlisted retention archive is a publication candidate; preparing it performed no publication, network GET, Source/Native dispatch or reader replay.
