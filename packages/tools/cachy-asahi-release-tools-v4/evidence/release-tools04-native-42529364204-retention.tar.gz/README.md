# ReleaseTools 0.4 finite native component evidence

Local prepublication review packet for Source f94c4ce6123468d1f991fc83fcba9090280b369d, GitHub run 42529364204, attempt 1, job 128879917081, artifact 13635839854. Root qualified only the finite generic native ARM ALPM ReleaseTools component.

artifact.zip is the whole original 799,864-byte GitHub ZIP, unchanged. Its SHA256 is 8d8ad9dbb7bfe5f8b8ec1f959421a0d249c0cff86916afc36bc48c4cb4922d10. The contained public-tree.tar is not duplicated separately. The capsule includes its existing public TEST-signature/key metadata; no production signing authority is granted.

The strict matching Reader9a ran once with actor denial and returned VALIDATED_NATIVE_RELEASE_TOOLS_ALPM_COMPONENT_EVIDENCE_ONLY. Root qualified install 0.1.0-1 -> upgrade 0.4.0-1 -> all eight commands from /usr and a moved prefix -> downgrade -> removal, Required/Required isolated TEST signatures, exact349 baseline restoration, payload12/23/12/0 and owned retirement. One build per version does not establish repeated0.4 byte reproducibility.

Native16K remains NOT QUALIFIED; physical M2 NOT RUN; performance NOT MEASURED; production trust and release NOT ADMITTED. Source identity, the full201 source map, the matching12 Python-module pins and public fact projections accompany the original ZIP. Original private custody records remain local.

This packet has not been published. Preparing it performed no network fetch, artifact/code execution or Reader replay.
