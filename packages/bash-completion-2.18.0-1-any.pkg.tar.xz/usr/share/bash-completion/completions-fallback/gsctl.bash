# 3rd party completion loader for commands emitting their completion using
# "$cmd completion bash --stdout".
#
# This serves as a fallback in case the completion is not installed otherwise.

eval -- "$("$1" completion bash --stdout 2>/dev/null)"
