# Source availability: speakersafetyd

The original tested build inputs are fixed at project Source
6983455c92ac39064909923836d7c5122d423f0f:
https://github.com/Gabriel-Kahen/cachy-asahi/tree/6983455c92ac39064909923836d7c5122d423f0f/packages/audio/speakersafetyd

The exact shared vendor source archive is available at:
https://raw.githubusercontent.com/Gabriel-Kahen/cachy-asahi/6983455c92ac39064909923836d7c5122d423f0f/packages/audio/speakersafetyd/cargo-vendor-117.tar.xz
SHA256:64cd55473b19f104f3a90570409d58c5ab69f63c61396541c4ad1e56e8d6293f
Size:5,733,816bytes. It contains all117 crates, original license texts and
Cargo checksum manifests. Source terms remain those in the individual crates.
This input URL responded HTTP200 to a HEAD request on2026-10-15; source hashes
here are pinned to retained input bytes and immutable project revision.

## colored 3.1.1 (MPL-2.0)

The exact unmodified component source is also available directly from its
primary registry at:
https://static.crates.io/crates/colored/colored-3.1.1.crate
SHA256:faf9468729b8cbcea668e36183cb69d317348c2e08e994829fb56ebfdfbaac34
Size:36,216bytes. This source remains available under MPL-2.0; its license and
notices are preserved in the archive and in the colored-3.1.1 sections of THIRD-PARTY-LICENSES.txt.
The primary URL responded HTTP200 to a HEAD request on2026-10-15. The retained
archive hash matches the tested Cargo lock/vendor package checksum. The
source used here was not modified.

These links identify actual original code/vendor inputs. They do not by
themselves supply a new notice-packaging revision or establish complete
corresponding-source delivery for any future package. That package's exact
recipe/notices/source index must be published with its binaries. This
proposal has not been installed or released.
