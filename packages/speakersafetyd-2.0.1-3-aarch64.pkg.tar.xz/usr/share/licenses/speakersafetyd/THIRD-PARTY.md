# Third-party components: speakersafetyd

This proposed notice set identifies all75 registry crates in the tested
Cargo lock, including build/procedural-macro/target-specific entries. It does
not assert every entry is linked into the final output. Source declarations
are reproduced unchanged; supplemental texts are separately identified.
The original root license remains in LICENSE or LICENCE.txt.

The proposed distribution choices are **MIT for configparser3.2.0** and
**Zlib for wide0.7.32** wherever present. Other original alternatives are
preserved with their texts. Additive Unicode and file-level notices remain.
These records do not globally relabel third-party source.

The root source declares MIT. The included colored3.1.1 component declares
MPL-2.0; its MPL text is under the colored-3.1.1/LICENSE section of THIRD-PARTY-LICENSES.txt. SOURCE.md
identifies the exact available source archive. The root MIT label does not
replace this component's license or source-notice terms.

wmidi's later upstream text and the nalgebra macro's workspace text, where
present, each have a SOURCE-ATTRIBUTION.md section in THIRD-PARTY-LICENSES.txt explaining their exact provenance
and remaining association limits. No missing copyright holder was invented.

| Crate/version | Unchanged upstream expression | Proposed selection / record |
| --- | --- | --- |
| alsa-sys@0.4.0 | `MIT` | MIT |
| alsa@0.11.0 | `Apache-2.0/MIT` | Original alternatives/terms retained; no additional choice recorded |
| android_system_properties@0.1.5 | `MIT/Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| anstream@1.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| anstyle-parse@1.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| anstyle-query@1.1.5 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| anstyle-wincon@3.0.11 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| anstyle@1.0.14 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| autocfg@1.5.1 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| bitflags@2.13.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| bumpalo@3.20.3 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| cc@1.2.64 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| cfg-if@1.0.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| chrono@0.4.45 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| clap-verbosity-flag@3.0.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| clap@4.6.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| clap_builder@4.6.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| clap_derive@4.6.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| clap_lex@1.1.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| colorchoice@1.0.5 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| colored@3.1.1 | `MPL-2.0` | MPL-2.0 |
| configparser@3.2.0 | `MIT OR LGPL-3.0-or-later` | MIT (proposed distribution selection) |
| core-foundation-sys@0.8.7 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| deranged@0.5.8 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| equivalent@1.0.2 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| errno@0.3.14 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| find-msvc-tools@0.1.9 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| futures-core@0.3.32 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| futures-task@0.3.32 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| futures-util@0.3.32 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| hashbrown@0.17.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| heck@0.5.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| iana-time-zone-haiku@0.1.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| iana-time-zone@0.1.65 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| indexmap@2.14.0 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| is_terminal_polyfill@1.70.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| js-sys@0.3.102 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| libc@0.2.186 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| log@0.4.32 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-conv@0.2.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-traits@0.2.19 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num_threads@0.1.7 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| once_cell@1.21.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| once_cell_polyfill@1.70.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| pin-project-lite@0.2.17 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| pkg-config@0.3.33 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| powerfmt@0.2.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| proc-macro2@1.0.106 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| quote@1.0.45 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| rustversion@1.0.22 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| serde_core@1.0.228 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| serde_derive@1.0.228 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| shlex@2.0.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| signal-hook-registry@1.4.8 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| signal-hook@0.4.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| simple_logger@5.2.0 | `MIT` | MIT |
| slab@0.4.12 | `MIT` | MIT |
| strsim@0.11.1 | `MIT` | MIT |
| syn@2.0.117 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| time-core@0.1.9 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| time-macros@0.2.29 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| time@0.3.49 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| unicode-ident@1.0.24 | `(MIT OR Apache-2.0) AND Unicode-3.0` | Original alternatives/terms retained; no additional choice recorded |
| utf8parse@0.2.2 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| wasm-bindgen-macro-support@0.2.125 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| wasm-bindgen-macro@0.2.125 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| wasm-bindgen-shared@0.2.125 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| wasm-bindgen@0.2.125 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-core@0.62.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-implement@0.60.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-interface@0.59.3 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-link@0.2.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-result@0.4.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-strings@0.5.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| windows-sys@0.61.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
