// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:insignificant

#ifndef QTLABSWAVEFRONTMESHGLOBAL_P_H
#define QTLABSWAVEFRONTMESHGLOBAL_P_H

#include <QtCore/qglobal.h>

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//

#include <QtLabsWavefrontMesh/qtlabswavefrontmeshexports.h>

#endif // QTLABSWAVEFRONTMESHGLOBAL_P_H
