# Copyright (C) 2022 The Qt Company Ltd.
# SPDX-License-Identifier: BSD-3-Clause

include(QtWaylandSetup)
qt_internal_get_wayland_protocols_dir(protocols_dir)

#####################################################################
## QWaylandDmabufClientBufferIntegrationPlugin Plugin:
#####################################################################

qt_find_package(EGL)

qt_internal_add_plugin(QWaylandDmabufUnstableClientBufferIntegrationPlugin
    OUTPUT_NAME qt-wayland-compositor-linux-dmabuf-unstable-v1
    PLUGIN_TYPE wayland-graphics-integration-server
    SOURCES
        ../../../../hardwareintegration/compositor/linux-dmabuf-v1/linuxdmabuf.cpp ../../../../hardwareintegration/compositor/linux-dmabuf-v1/linuxdmabuf.h
        ../../../../hardwareintegration/compositor/linux-dmabuf-v1/linuxdmabufclientbufferintegration.cpp ../../../../hardwareintegration/compositor/linux-dmabuf-v1/linuxdmabufclientbufferintegration.h
        main.cpp
    INCLUDE_DIRECTORIES
        ../../../../hardwareintegration/compositor/linux-dmabuf-v1
    LIBRARIES
        EGL::EGL
        Libdrm::Libdrm
        Wayland::Server
        Qt::CorePrivate
        Qt::GuiPrivate
        Qt::WaylandCompositor
        Qt::WaylandCompositorPrivate
    ATTRIBUTION_FILE_DIR_PATHS
        ${protocols_dir}/linux-dmabuf
)

qt6_generate_wayland_protocol_server_sources(QWaylandDmabufUnstableClientBufferIntegrationPlugin
    PRIVATE_CODE
    FILES
        ${protocols_dir}/linux-dmabuf/linux-dmabuf-v1.xml
)
