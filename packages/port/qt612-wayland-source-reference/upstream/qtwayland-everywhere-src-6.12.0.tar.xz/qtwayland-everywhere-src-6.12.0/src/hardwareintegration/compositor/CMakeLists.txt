# Copyright (C) 2022 The Qt Company Ltd.
# SPDX-License-Identifier: BSD-3-Clause

# Generated from compositor.pro.

if(QT_FEATURE_wayland_egl)
    add_subdirectory(wayland-egl)
endif()
