# Third-party components: triforce-lv2

This proposed notice set identifies all38 registry crates in the tested
Cargo lock, including build/procedural-macro/target-specific entries. It does
not assert every entry is linked into the final output. Source declarations
are reproduced unchanged; supplemental texts are separately identified.
The original root license remains in LICENSE or LICENCE.txt.

The proposed distribution choices are **MIT for configparser3.2.0** and
**Zlib for wide0.7.32** wherever present. Other original alternatives are
preserved with their texts. Additive Unicode and file-level notices remain.
These records do not globally relabel third-party source.

For the combined Triforce distribution, this proposal explicitly uses **GNU
GPL version3**, as allowed by the root source's GPL-2.0-or-later declaration,
while preserving third-party Apache/MIT/Zlib/Unicode terms and notices. The
original root source declaration and GPLv2 LICENCE.txt remain unchanged.
GPL-3.0.txt provides the complete GPLv3 text from the pinned SPDX license data.
This route addresses the observed Apache-only components without asserting
that a GPLv2-only combination is compatible. It is a distribution proposal
for review, not an overall compliance determination.

wmidi's later upstream text and the nalgebra macro's workspace text, where
present, each have a SOURCE-ATTRIBUTION.md section in THIRD-PARTY-LICENSES.txt explaining their exact provenance
and remaining association limits. No missing copyright holder was invented.

| Crate/version | Unchanged upstream expression | Proposed selection / record |
| --- | --- | --- |
| approx@0.5.1 | `Apache-2.0` | Apache-2.0 |
| autocfg@1.4.0 | `Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| bytemuck@1.23.0 | `Zlib OR Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| lv2-atom@2.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-core-derive@2.1.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-core@3.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-midi@1.2.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-sys@2.0.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-units@0.1.3 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2-urid@2.1.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| lv2@0.6.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| matrixmultiply@0.3.10 | `MIT/Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| nalgebra-macros@0.2.2 | `Apache-2.0` | Apache-2.0 |
| nalgebra@0.33.2 | `Apache-2.0` | Apache-2.0 |
| num-bigint@0.4.6 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-complex@0.4.6 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-integer@0.1.46 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-rational@0.4.2 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| num-traits@0.2.19 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| paste@1.0.15 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| primal-check@0.3.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| proc-macro2@1.0.95 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| quote@1.0.40 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| rawpointer@0.2.1 | `MIT/Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| rustfft@6.3.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| safe_arch@0.7.4 | `Zlib OR Apache-2.0 OR MIT` | Original alternatives/terms retained; no additional choice recorded |
| simba@0.9.0 | `Apache-2.0` | Apache-2.0 |
| strength_reduce@0.2.4 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| syn@1.0.109 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| syn@2.0.101 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| transpose@0.2.3 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| typenum@1.18.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| unicode-ident@1.0.18 | `(MIT OR Apache-2.0) AND Unicode-3.0` | Original alternatives/terms retained; no additional choice recorded |
| urid-derive@0.1.1 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| urid@0.1.0 | `MIT OR Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| version_check@0.9.5 | `MIT/Apache-2.0` | Original alternatives/terms retained; no additional choice recorded |
| wide@0.7.32 | `Zlib OR Apache-2.0 OR MIT` | Zlib (proposed distribution selection) |
| wmidi@3.1.0 | `MIT` | MIT |
