/* GSK - The GTK Scene Kit
 * Copyright 2016  Endless 
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#if !defined (__GSK_H_INSIDE__) && !defined (GTK_COMPILATION)
#error "Only <gsk/gsk.h> can be included directly."
#endif

#include <graphene.h>
#include <gdk/gdktypes.h>
#include <gsk/gskenums.h>

G_BEGIN_DECLS

typedef struct _GskPath                 GskPath;
typedef struct _GskPathBuilder          GskPathBuilder;
typedef struct _GskPathMeasure          GskPathMeasure;
typedef struct _GskPathPoint            GskPathPoint;
typedef unsigned                        GskRectSnap;
typedef struct _GskRenderer             GskRenderer;
typedef struct _GskRenderNode           GskRenderNode;
typedef struct _GskRenderReplay         GskRenderReplay;
typedef struct _GskRoundedRect          GskRoundedRect;
typedef struct _GskStroke               GskStroke;
typedef struct _GskTransform            GskTransform;
typedef struct _GskComponentTransfer    GskComponentTransfer;

G_END_DECLS
